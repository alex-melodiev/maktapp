-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Авг 09 2017 г., 15:34
-- Версия сервера: 10.1.25-MariaDB
-- Версия PHP: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `maktapp_db`
--

-- --------------------------------------------------------

--
-- Структура таблицы `academic_year`
--

CREATE TABLE `academic_year` (
  `id` int(11) NOT NULL,
  `start_year` int(11) NOT NULL,
  `end_year` int(11) NOT NULL,
  `active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `academic_year`
--

INSERT INTO `academic_year` (`id`, `start_year`, `end_year`, `active`) VALUES
(1, 2017, 2018, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `article`
--

CREATE TABLE `article` (
  `id` int(11) NOT NULL,
  `slug` varchar(1024) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `view` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `thumbnail_base_url` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thumbnail_path` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `published_at` int(11) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `article_attachment`
--

CREATE TABLE `article_attachment` (
  `id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `base_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `order` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `article_category`
--

CREATE TABLE `article_category` (
  `id` int(11) NOT NULL,
  `slug` varchar(1024) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci,
  `parent_id` int(11) DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `article_category`
--

INSERT INTO `article_category` (`id`, `slug`, `title`, `body`, `parent_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 'news', 'News', NULL, NULL, 1, 1501684576, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `lesson_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `class`
--

CREATE TABLE `class` (
  `id` int(11) NOT NULL,
  `number` int(11) NOT NULL,
  `register` varchar(1) CHARACTER SET utf8 NOT NULL,
  `curator_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `class`
--

INSERT INTO `class` (`id`, `number`, `register`, `curator_id`, `school_id`) VALUES
(1, 3, '2', 5, 1),
(2, 3, 'Г', 5, 1),
(3, 2, 'В', 5, 1),
(4, 8, 'А', 5, 1),
(5, 3, 'Д', 5, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `file_storage_item`
--

CREATE TABLE `file_storage_item` (
  `id` int(11) NOT NULL,
  `component` varchar(255) NOT NULL,
  `base_url` varchar(1024) NOT NULL,
  `path` varchar(1024) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `upload_ip` varchar(15) DEFAULT NULL,
  `created_at` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `homework`
--

CREATE TABLE `homework` (
  `id` int(11) NOT NULL,
  `lesson_id` int(11) NOT NULL,
  `note` text NOT NULL,
  `deadline` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `i18n_message`
--

CREATE TABLE `i18n_message` (
  `id` int(11) NOT NULL DEFAULT '0',
  `language` varchar(16) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `translation` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `i18n_source_message`
--

CREATE TABLE `i18n_source_message` (
  `id` int(11) NOT NULL,
  `category` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `key_storage_item`
--

CREATE TABLE `key_storage_item` (
  `key` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `updated_at` int(11) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `key_storage_item`
--

INSERT INTO `key_storage_item` (`key`, `value`, `comment`, `updated_at`, `created_at`) VALUES
('backend.layout-boxed', '0', NULL, NULL, NULL),
('backend.layout-collapsed-sidebar', '0', NULL, NULL, NULL),
('backend.layout-fixed', '0', NULL, NULL, NULL),
('backend.theme-skin', 'skin-blue', 'skin-blue, skin-black, skin-purple, skin-green, skin-red, skin-yellow', NULL, NULL),
('frontend.maintenance', 'disabled', 'Set it to \"true\" to turn on maintenance mode', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `lesson`
--

CREATE TABLE `lesson` (
  `id` int(11) NOT NULL,
  `academic_year_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `quarter_id` int(11) NOT NULL,
  `timing_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `week_type` varchar(12) CHARACTER SET utf8 NOT NULL,
  `day` varchar(12) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `lesson`
--

INSERT INTO `lesson` (`id`, `academic_year_id`, `subject_id`, `status`, `class_id`, `quarter_id`, `timing_id`, `teacher_id`, `school_id`, `week_type`, `day`) VALUES
(1, 1, 1, 0, 2, 1, 1, 5, 1, '1', '1'),
(2, 1, 2, 0, 2, 1, 2, 5, 1, '1', '1'),
(3, 1, 3, 0, 2, 1, 3, 6, 1, '1', '1'),
(4, 1, 2, 0, 2, 1, 3, 5, 1, '1', '1');

-- --------------------------------------------------------

--
-- Структура таблицы `lesson_data`
--

CREATE TABLE `lesson_data` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `lesson_id` int(11) NOT NULL,
  `presence` int(11) NOT NULL,
  `homework_mark` int(11) NOT NULL,
  `homework_note` text NOT NULL,
  `additional_mark` int(11) NOT NULL,
  `additional_note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `mark`
--

CREATE TABLE `mark` (
  `id` int(11) NOT NULL,
  `lesson_id` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `note` text NOT NULL,
  `type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `page`
--

CREATE TABLE `page` (
  `id` int(11) NOT NULL,
  `slug` varchar(2048) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `view` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` smallint(6) NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `page`
--

INSERT INTO `page` (`id`, `slug`, `title`, `body`, `view`, `status`, `created_at`, `updated_at`) VALUES
(1, 'about', 'About', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', NULL, 1, 1501684576, 1501684576);

-- --------------------------------------------------------

--
-- Структура таблицы `quarter`
--

CREATE TABLE `quarter` (
  `id` int(11) NOT NULL,
  `start_date` timestamp NULL DEFAULT NULL,
  `end_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `academic_year_id` int(11) NOT NULL,
  `number` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `quarter`
--

INSERT INTO `quarter` (`id`, `start_date`, `end_date`, `academic_year_id`, `number`) VALUES
(1, '2017-09-01 19:00:00', '2017-11-10 19:00:00', 1, 1),
(2, '2017-11-22 19:00:00', '2018-01-11 19:00:00', 1, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `rbac_auth_assignment`
--

CREATE TABLE `rbac_auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `rbac_auth_assignment`
--

INSERT INTO `rbac_auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES
('administrator', 1, 1501698327),
('director', 4, 1501698671),
('manager', 2, 1501684589),
('student', 6, 1502281885),
('student', 7, 1502281876),
('teacher', 5, 1501698707),
('user', 3, 1501684589);

-- --------------------------------------------------------

--
-- Структура таблицы `rbac_auth_item`
--

CREATE TABLE `rbac_auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` blob,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `rbac_auth_item`
--

INSERT INTO `rbac_auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`) VALUES
('administrator', 1, NULL, NULL, NULL, 1501684589, 1501684589),
('director', 1, NULL, NULL, NULL, NULL, NULL),
('editOwnModel', 2, NULL, 'ownModelRule', NULL, 1501684589, 1501684589),
('loginToBackend', 2, NULL, NULL, NULL, 1501684589, 1501684589),
('manager', 1, NULL, NULL, NULL, 1501684589, 1501684589),
('student', 1, NULL, NULL, NULL, NULL, NULL),
('teacher', 1, NULL, NULL, NULL, NULL, NULL),
('user', 1, NULL, NULL, NULL, 1501684589, 1501684589);

-- --------------------------------------------------------

--
-- Структура таблицы `rbac_auth_item_child`
--

CREATE TABLE `rbac_auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `rbac_auth_item_child`
--

INSERT INTO `rbac_auth_item_child` (`parent`, `child`) VALUES
('administrator', 'manager'),
('manager', 'loginToBackend'),
('manager', 'user'),
('user', 'editOwnModel');

-- --------------------------------------------------------

--
-- Структура таблицы `rbac_auth_rule`
--

CREATE TABLE `rbac_auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` blob,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `rbac_auth_rule`
--

INSERT INTO `rbac_auth_rule` (`name`, `data`, `created_at`, `updated_at`) VALUES
('ownModelRule', 0x4f3a32393a22636f6d6d6f6e5c726261635c72756c655c4f776e4d6f64656c52756c65223a333a7b733a343a226e616d65223b733a31323a226f776e4d6f64656c52756c65223b733a393a22637265617465644174223b693a313530313638343538393b733a393a22757064617465644174223b693a313530313638343538393b7d, 1501684589, 1501684589);

-- --------------------------------------------------------

--
-- Структура таблицы `school`
--

CREATE TABLE `school` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `region` varchar(50) NOT NULL,
  `city` varchar(20) NOT NULL,
  `area` varchar(50) NOT NULL,
  `address` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `subject`
--

CREATE TABLE `subject` (
  `id` int(11) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `subject`
--

INSERT INTO `subject` (`id`, `name`) VALUES
(1, 'Английский'),
(2, 'Русский'),
(3, 'Математика'),
(4, 'История');

-- --------------------------------------------------------

--
-- Структура таблицы `system_db_migration`
--

CREATE TABLE `system_db_migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `system_db_migration`
--

INSERT INTO `system_db_migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1501684569),
('m140703_123000_user', 1501684574),
('m140703_123055_log', 1501684574),
('m140703_123104_page', 1501684574),
('m140703_123803_article', 1501684574),
('m140703_123813_rbac', 1501684574),
('m140709_173306_widget_menu', 1501684574),
('m140709_173333_widget_text', 1501684574),
('m140712_123329_widget_carousel', 1501684574),
('m140805_084745_key_storage_item', 1501684574),
('m141012_101932_i18n_tables', 1501684574),
('m150318_213934_file_storage_item', 1501684574),
('m150414_195800_timeline_event', 1501684574),
('m150725_192740_seed_data', 1501684576),
('m150929_074021_article_attachment_order', 1501684576),
('m160203_095604_user_token', 1501684576);

-- --------------------------------------------------------

--
-- Структура таблицы `system_log`
--

CREATE TABLE `system_log` (
  `id` bigint(20) NOT NULL,
  `level` int(11) DEFAULT NULL,
  `category` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `log_time` double DEFAULT NULL,
  `prefix` text COLLATE utf8_unicode_ci,
  `message` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `system_log`
--

INSERT INTO `system_log` (`id`, `level`, `category`, `log_time`, `prefix`, `message`) VALUES
(1, 2, 'yii\\debug\\Module::checkAccess', 1501684676.6533, '[frontend][/frontend/web/]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.102.222'),
(2, 2, 'yii\\debug\\Module::checkAccess', 1501684676.6544, '[frontend][/frontend/web/]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.102.222'),
(3, 2, 'yii\\debug\\Module::checkAccess', 1501684681.3173, '[frontend][/frontend/web/page/about]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.102.222'),
(4, 2, 'yii\\debug\\Module::checkAccess', 1501684681.3189, '[frontend][/frontend/web/page/about]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.102.222'),
(5, 2, 'yii\\debug\\Module::checkAccess', 1501693170.7592, '[frontend][/]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(6, 2, 'yii\\debug\\Module::checkAccess', 1501693170.7603, '[frontend][/]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(7, 2, 'yii\\debug\\Module::checkAccess', 1501693181.0863, '[frontend][/page/about]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(8, 2, 'yii\\debug\\Module::checkAccess', 1501693181.0874, '[frontend][/page/about]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(9, 2, 'yii\\debug\\Module::checkAccess', 1501693183.3155, '[frontend][/article/index]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(10, 2, 'yii\\debug\\Module::checkAccess', 1501693183.3166, '[frontend][/article/index]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(11, 2, 'yii\\debug\\Module::checkAccess', 1501693185.1341, '[frontend][/site/contact]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(12, 2, 'yii\\debug\\Module::checkAccess', 1501693185.1358, '[frontend][/site/contact]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(13, 2, 'yii\\debug\\Module::checkAccess', 1501693185.5122, '[frontend][/site/captcha?v=598205011df0c]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(14, 2, 'yii\\debug\\Module::checkAccess', 1501693187.4837, '[frontend][/user/sign-in/signup]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(15, 2, 'yii\\debug\\Module::checkAccess', 1501693187.485, '[frontend][/user/sign-in/signup]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(16, 2, 'yii\\debug\\Module::checkAccess', 1501693193.1028, '[frontend][/user/sign-in/login]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(17, 2, 'yii\\debug\\Module::checkAccess', 1501693193.1041, '[frontend][/user/sign-in/login]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(18, 2, 'yii\\debug\\Module::checkAccess', 1501693680.6536, '[frontend][/]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(19, 2, 'yii\\debug\\Module::checkAccess', 1501693680.6546, '[frontend][/]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(20, 2, 'yii\\debug\\Module::checkAccess', 1501693687.1239, '[frontend][/backend]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(21, 2, 'yii\\debug\\Module::checkAccess', 1501693687.1256, '[frontend][/backend]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(22, 2, 'yii\\debug\\Module::checkAccess', 1501693966.3175, '[frontend][/]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(23, 2, 'yii\\debug\\Module::checkAccess', 1501693966.3186, '[frontend][/]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(24, 2, 'yii\\debug\\Module::checkAccess', 1501694395.1899, '[frontend][/]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(25, 2, 'yii\\debug\\Module::checkAccess', 1501694395.1926, '[frontend][/]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(26, 2, 'yii\\debug\\Module::checkAccess', 1501694593.6468, '[backend][/]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(27, 2, 'yii\\debug\\Module::checkAccess', 1501694593.8682, '[backend][/sign-in/login]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(28, 2, 'yii\\debug\\Module::checkAccess', 1501694593.8716, '[backend][/sign-in/login]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(29, 2, 'yii\\debug\\Module::checkAccess', 1501694603.9244, '[backend][/sign-in/login]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(30, 2, 'yii\\debug\\Module::checkAccess', 1501694604.1872, '[backend][/]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(31, 2, 'yii\\debug\\Module::checkAccess', 1501694604.1888, '[backend][/]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(32, 2, 'yii\\debug\\Module::checkAccess', 1501694616.211, '[backend][/log/view?id=29]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(33, 2, 'yii\\debug\\Module::checkAccess', 1501694616.2133, '[backend][/log/view?id=29]', 'Access to debugger is denied due to IP address restriction. The requesting IP address is 213.230.77.138'),
(34, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501699763.1237, '[frontend][/gii/crud]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(35, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501699775.8907, '[frontend][/gii/crud]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(36, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501699838.308, '[frontend][/gii/crud]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(37, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501699846.1016, '[frontend][/gii/crud]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(38, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501699916.5977, '[frontend][/gii/crud]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(39, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501699921.566, '[frontend][/gii/crud]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(40, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501699983.8299, '[frontend][/gii/crud]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(41, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501699987.5439, '[frontend][/gii/crud]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(42, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501700012.3565, '[frontend][/gii/crud]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(43, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501700017.0518, '[frontend][/gii/crud]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(44, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501700058.617, '[frontend][/gii/crud]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(45, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501700072.8356, '[frontend][/gii/crud]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(46, 1, 'yii\\base\\ErrorException:4', 1501703166.9643, '[frontend][/student]', 'exception \'yii\\base\\ErrorException\' with message \'syntax error, unexpected \';\'\' in /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/models/StudentSearch.php:81\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleFatalError()\n#1 {main}'),
(47, 1, 'yii\\base\\ErrorException:4', 1501703178.4656, '[frontend][/student]', 'exception \'yii\\base\\ErrorException\' with message \'syntax error, unexpected \';\'\' in /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/models/StudentSearch.php:81\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleFatalError()\n#1 {main}'),
(48, 1, 'yii\\base\\UnknownMethodException', 1501703192.1746, '[frontend][/student]', 'exception \'yii\\base\\UnknownMethodException\' with message \'Calling unknown method: common\\models\\query\\UserQuery::addFilterWhere()\' in /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Component.php:290\nStack trace:\n#0 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/models/StudentSearch.php(79): yii\\base\\Component->__call(\'addFilterWhere\', Array)\n#1 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/models/StudentSearch.php(79): common\\models\\query\\UserQuery->addFilterWhere(\'=\', \'rbac_auth_assig...\', \'student\')\n#2 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/controllers/StudentController.php(39): common\\models\\StudentSearch->search(Array)\n#3 [internal function]: frontend\\controllers\\StudentController->actionIndex()\n#4 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/InlineAction.php(57): call_user_func_array(Array, Array)\n#5 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#6 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Module.php(523): yii\\base\\Controller->runAction(\'\', Array)\n#7 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/web/Application.php(102): yii\\base\\Module->runAction(\'student\', Array)\n#8 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#9 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/web/index.php(22): yii\\base\\Application->run()\n#10 {main}'),
(49, 1, 'yii\\base\\InvalidParamException', 1501703239.7647, '[frontend][/student]', 'exception \'yii\\base\\UnknownMethodException\' with message \'Calling unknown method: common\\models\\User::getrbac_auth_assignment()\' in /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Component.php:290\nStack trace:\n#0 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/BaseActiveRecord.php(1192): yii\\base\\Component->__call(\'getrbac_auth_as...\', Array)\n#1 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/BaseActiveRecord.php(1192): common\\models\\User->getrbac_auth_assignment()\n#2 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/ActiveQuery.php(513): yii\\db\\BaseActiveRecord->getRelation(\'<span class=\"st...\')\n#3 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/ActiveQuery.php(441): yii\\db\\ActiveQuery->joinWithRelations(Object(common\\models\\User), \'[<span class=\"s...\', \'<span class=\"st...\')\n#4 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/ActiveQuery.php(148): yii\\db\\ActiveQuery->buildJoinWith()\n#5 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/QueryBuilder.php(108): yii\\db\\ActiveQuery->prepare(Object(yii\\db\\mysql\\QueryBuilder))\n#6 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/ActiveQuery.php(318): yii\\db\\QueryBuilder->build(Object(common\\models\\query\\UserQuery))\n#7 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/Query.php(426): yii\\db\\ActiveQuery->createCommand(Object(yii\\db\\Connection))\n#8 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/ActiveQuery.php(339): yii\\db\\Query->queryScalar(\'<span class=\"st...\', Object(yii\\db\\Connection))\n#9 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/Query.php(319): yii\\db\\ActiveQuery->queryScalar(\'<span class=\"st...\', \'<span class=\"ke...\')\n#10 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/ActiveDataProvider.php(169): yii\\db\\Query->count(\'<span class=\"st...\', \'<span class=\"ke...\')\n#11 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(169): yii\\data\\ActiveDataProvider->prepareTotalCount()\n#12 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/ActiveDataProvider.php(106): yii\\data\\BaseDataProvider->getTotalCount()\n#13 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(101): yii\\data\\ActiveDataProvider->prepareModels()\n#14 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(114): yii\\data\\BaseDataProvider->prepare()\n#15 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(155): yii\\data\\BaseDataProvider->getModels()\n#16 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(189): yii\\data\\BaseDataProvider->getCount()\n#17 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(157): yii\\widgets\\BaseListView->renderSummary()\n#18 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/grid/GridView.php(316): yii\\widgets\\BaseListView->renderSection(\'<span class=\"st...\')\n#19 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(134): yii\\grid\\GridView->renderSection(\'<span class=\"st...\')\n#20 [internal function]: yii\\widgets\\BaseListView->yii\\widgets\\{closure}(\'[<span class=\"s...\')\n#21 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(137): preg_replace_callback(\'<span class=\"st...\', Object(Closure), \'<span class=\"st...\')\n#22 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/grid/GridView.php(291): yii\\widgets\\BaseListView->run()\n#23 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Widget.php(139): yii\\grid\\GridView->run()\n#24 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/views/student/index.php(42): yii\\base\\Widget::widget(\'[<span class=\"s...\')\n#25 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/View.php(330): require(\'/var/www/hamste...\')\n#26 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/View.php(250): yii\\base\\View->renderPhpFile(\'<span class=\"st...\', \'[<span class=\"s...\')\n#27 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/View.php(152): yii\\base\\View->renderFile(\'<span class=\"st...\', \'[<span class=\"s...\', Object(frontend\\controllers\\StudentController))\n#28 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Controller.php(381): yii\\base\\View->render(\'<span class=\"st...\', \'[<span class=\"s...\', Object(frontend\\controllers\\StudentController))\n#29 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/controllers/StudentController.php(44): yii\\base\\Controller->render(\'<span class=\"st...\', \'[<span class=\"s...\')\n#30 [internal function]: frontend\\controllers\\StudentController->actionIndex()\n#31 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/InlineAction.php(57): call_user_func_array(\'[<span class=\"t...\', \'[]\')\n#32 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Controller.php(156): yii\\base\\InlineAction->runWithParams(\'[]\')\n#33 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Module.php(523): yii\\base\\Controller->runAction(\'<span class=\"st...\', \'[]\')\n#34 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/web/Application.php(102): yii\\base\\Module->runAction(\'<span class=\"st...\', \'[]\')\n#35 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#36 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/web/index.php(22): yii\\base\\Application->run()\n#37 {main}\n\nNext exception \'yii\\base\\InvalidParamException\' with message \'common\\models\\User has no relation named \"rbac_auth_assignment\".\' in /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/BaseActiveRecord.php:1195\nStack trace:\n#0 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/ActiveQuery.php(513): yii\\db\\BaseActiveRecord->getRelation(\'<span class=\"st...\')\n#1 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/ActiveQuery.php(441): yii\\db\\ActiveQuery->joinWithRelations(Object(common\\models\\User), \'[<span class=\"s...\', \'<span class=\"st...\')\n#2 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/ActiveQuery.php(148): yii\\db\\ActiveQuery->buildJoinWith()\n#3 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/QueryBuilder.php(108): yii\\db\\ActiveQuery->prepare(Object(yii\\db\\mysql\\QueryBuilder))\n#4 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/ActiveQuery.php(318): yii\\db\\QueryBuilder->build(Object(common\\models\\query\\UserQuery))\n#5 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/Query.php(426): yii\\db\\ActiveQuery->createCommand(Object(yii\\db\\Connection))\n#6 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/ActiveQuery.php(339): yii\\db\\Query->queryScalar(\'<span class=\"st...\', Object(yii\\db\\Connection))\n#7 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/Query.php(319): yii\\db\\ActiveQuery->queryScalar(\'<span class=\"st...\', \'<span class=\"ke...\')\n#8 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/ActiveDataProvider.php(169): yii\\db\\Query->count(\'<span class=\"st...\', \'<span class=\"ke...\')\n#9 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(169): yii\\data\\ActiveDataProvider->prepareTotalCount()\n#10 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/ActiveDataProvider.php(106): yii\\data\\BaseDataProvider->getTotalCount()\n#11 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(101): yii\\data\\ActiveDataProvider->prepareModels()\n#12 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(114): yii\\data\\BaseDataProvider->prepare()\n#13 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(155): yii\\data\\BaseDataProvider->getModels()\n#14 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(189): yii\\data\\BaseDataProvider->getCount()\n#15 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(157): yii\\widgets\\BaseListView->renderSummary()\n#16 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/grid/GridView.php(316): yii\\widgets\\BaseListView->renderSection(\'<span class=\"st...\')\n#17 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(134): yii\\grid\\GridView->renderSection(\'<span class=\"st...\')\n#18 [internal function]: yii\\widgets\\BaseListView->yii\\widgets\\{closure}(\'[<span class=\"s...\')\n#19 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(137): preg_replace_callback(\'<span class=\"st...\', Object(Closure), \'<span class=\"st...\')\n#20 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/grid/GridView.php(291): yii\\widgets\\BaseListView->run()\n#21 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Widget.php(139): yii\\grid\\GridView->run()\n#22 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/views/student/index.php(42): yii\\base\\Widget::widget(\'[<span class=\"s...\')\n#23 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/View.php(330): require(\'/var/www/hamste...\')\n#24 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/View.php(250): yii\\base\\View->renderPhpFile(\'<span class=\"st...\', \'[<span class=\"s...\')\n#25 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/View.php(152): yii\\base\\View->renderFile(\'<span class=\"st...\', \'[<span class=\"s...\', Object(frontend\\controllers\\StudentController))\n#26 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Controller.php(381): yii\\base\\View->render(\'<span class=\"st...\', \'[<span class=\"s...\', Object(frontend\\controllers\\StudentController))\n#27 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/controllers/StudentController.php(44): yii\\base\\Controller->render(\'<span class=\"st...\', \'[<span class=\"s...\')\n#28 [internal function]: frontend\\controllers\\StudentController->actionIndex()\n#29 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/InlineAction.php(57): call_user_func_array(\'[<span class=\"t...\', \'[]\')\n#30 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Controller.php(156): yii\\base\\InlineAction->runWithParams(\'[]\')\n#31 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Module.php(523): yii\\base\\Controller->runAction(\'<span class=\"st...\', \'[]\')\n#32 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/web/Application.php(102): yii\\base\\Module->runAction(\'<span class=\"st...\', \'[]\')\n#33 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#34 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/web/index.php(22): yii\\base\\Application->run()\n#35 {main}'),
(50, 1, 'yii\\base\\InvalidParamException', 1501703793.4869, '[frontend][/student]', 'exception \'yii\\base\\UnknownMethodException\' with message \'Calling unknown method: common\\models\\User::getrbac_auth_assignment()\' in /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Component.php:290\nStack trace:\n#0 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/BaseActiveRecord.php(1192): yii\\base\\Component->__call(\'getrbac_auth_as...\', Array)\n#1 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/BaseActiveRecord.php(1192): common\\models\\User->getrbac_auth_assignment()\n#2 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/ActiveQuery.php(513): yii\\db\\BaseActiveRecord->getRelation(\'<span class=\"st...\')\n#3 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/ActiveQuery.php(441): yii\\db\\ActiveQuery->joinWithRelations(Object(common\\models\\User), \'[<span class=\"s...\', \'<span class=\"st...\')\n#4 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/ActiveQuery.php(148): yii\\db\\ActiveQuery->buildJoinWith()\n#5 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/QueryBuilder.php(108): yii\\db\\ActiveQuery->prepare(Object(yii\\db\\mysql\\QueryBuilder))\n#6 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/ActiveQuery.php(318): yii\\db\\QueryBuilder->build(Object(common\\models\\query\\UserQuery))\n#7 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/Query.php(426): yii\\db\\ActiveQuery->createCommand(Object(yii\\db\\Connection))\n#8 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/ActiveQuery.php(339): yii\\db\\Query->queryScalar(\'<span class=\"st...\', Object(yii\\db\\Connection))\n#9 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/Query.php(319): yii\\db\\ActiveQuery->queryScalar(\'<span class=\"st...\', \'<span class=\"ke...\')\n#10 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/ActiveDataProvider.php(169): yii\\db\\Query->count(\'<span class=\"st...\', \'<span class=\"ke...\')\n#11 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(169): yii\\data\\ActiveDataProvider->prepareTotalCount()\n#12 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/ActiveDataProvider.php(106): yii\\data\\BaseDataProvider->getTotalCount()\n#13 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(101): yii\\data\\ActiveDataProvider->prepareModels()\n#14 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(114): yii\\data\\BaseDataProvider->prepare()\n#15 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(155): yii\\data\\BaseDataProvider->getModels()\n#16 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(189): yii\\data\\BaseDataProvider->getCount()\n#17 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(157): yii\\widgets\\BaseListView->renderSummary()\n#18 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/grid/GridView.php(316): yii\\widgets\\BaseListView->renderSection(\'<span class=\"st...\')\n#19 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(134): yii\\grid\\GridView->renderSection(\'<span class=\"st...\')\n#20 [internal function]: yii\\widgets\\BaseListView->yii\\widgets\\{closure}(\'[<span class=\"s...\')\n#21 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(137): preg_replace_callback(\'<span class=\"st...\', Object(Closure), \'<span class=\"st...\')\n#22 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/grid/GridView.php(291): yii\\widgets\\BaseListView->run()\n#23 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Widget.php(139): yii\\grid\\GridView->run()\n#24 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/views/student/index.php(42): yii\\base\\Widget::widget(\'[<span class=\"s...\')\n#25 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/View.php(330): require(\'/var/www/hamste...\')\n#26 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/View.php(250): yii\\base\\View->renderPhpFile(\'<span class=\"st...\', \'[<span class=\"s...\')\n#27 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/View.php(152): yii\\base\\View->renderFile(\'<span class=\"st...\', \'[<span class=\"s...\', Object(frontend\\controllers\\StudentController))\n#28 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Controller.php(381): yii\\base\\View->render(\'<span class=\"st...\', \'[<span class=\"s...\', Object(frontend\\controllers\\StudentController))\n#29 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/controllers/StudentController.php(44): yii\\base\\Controller->render(\'<span class=\"st...\', \'[<span class=\"s...\')\n#30 [internal function]: frontend\\controllers\\StudentController->actionIndex()\n#31 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/InlineAction.php(57): call_user_func_array(\'[<span class=\"t...\', \'[]\')\n#32 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Controller.php(156): yii\\base\\InlineAction->runWithParams(\'[]\')\n#33 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Module.php(523): yii\\base\\Controller->runAction(\'<span class=\"st...\', \'[]\')\n#34 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/web/Application.php(102): yii\\base\\Module->runAction(\'<span class=\"st...\', \'[]\')\n#35 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#36 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/web/index.php(22): yii\\base\\Application->run()\n#37 {main}\n\nNext exception \'yii\\base\\InvalidParamException\' with message \'common\\models\\User has no relation named \"rbac_auth_assignment\".\' in /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/BaseActiveRecord.php:1195\nStack trace:\n#0 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/ActiveQuery.php(513): yii\\db\\BaseActiveRecord->getRelation(\'<span class=\"st...\')\n#1 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/ActiveQuery.php(441): yii\\db\\ActiveQuery->joinWithRelations(Object(common\\models\\User), \'[<span class=\"s...\', \'<span class=\"st...\')\n#2 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/ActiveQuery.php(148): yii\\db\\ActiveQuery->buildJoinWith()\n#3 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/QueryBuilder.php(108): yii\\db\\ActiveQuery->prepare(Object(yii\\db\\mysql\\QueryBuilder))\n#4 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/ActiveQuery.php(318): yii\\db\\QueryBuilder->build(Object(common\\models\\query\\UserQuery))\n#5 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/Query.php(426): yii\\db\\ActiveQuery->createCommand(Object(yii\\db\\Connection))\n#6 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/ActiveQuery.php(339): yii\\db\\Query->queryScalar(\'<span class=\"st...\', Object(yii\\db\\Connection))\n#7 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/Query.php(319): yii\\db\\ActiveQuery->queryScalar(\'<span class=\"st...\', \'<span class=\"ke...\')\n#8 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/ActiveDataProvider.php(169): yii\\db\\Query->count(\'<span class=\"st...\', \'<span class=\"ke...\')\n#9 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(169): yii\\data\\ActiveDataProvider->prepareTotalCount()\n#10 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/ActiveDataProvider.php(106): yii\\data\\BaseDataProvider->getTotalCount()\n#11 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(101): yii\\data\\ActiveDataProvider->prepareModels()\n#12 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(114): yii\\data\\BaseDataProvider->prepare()\n#13 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(155): yii\\data\\BaseDataProvider->getModels()\n#14 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(189): yii\\data\\BaseDataProvider->getCount()\n#15 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(157): yii\\widgets\\BaseListView->renderSummary()\n#16 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/grid/GridView.php(316): yii\\widgets\\BaseListView->renderSection(\'<span class=\"st...\')\n#17 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(134): yii\\grid\\GridView->renderSection(\'<span class=\"st...\')\n#18 [internal function]: yii\\widgets\\BaseListView->yii\\widgets\\{closure}(\'[<span class=\"s...\')\n#19 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(137): preg_replace_callback(\'<span class=\"st...\', Object(Closure), \'<span class=\"st...\')\n#20 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/grid/GridView.php(291): yii\\widgets\\BaseListView->run()\n#21 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Widget.php(139): yii\\grid\\GridView->run()\n#22 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/views/student/index.php(42): yii\\base\\Widget::widget(\'[<span class=\"s...\')\n#23 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/View.php(330): require(\'/var/www/hamste...\')\n#24 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/View.php(250): yii\\base\\View->renderPhpFile(\'<span class=\"st...\', \'[<span class=\"s...\')\n#25 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/View.php(152): yii\\base\\View->renderFile(\'<span class=\"st...\', \'[<span class=\"s...\', Object(frontend\\controllers\\StudentController))\n#26 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Controller.php(381): yii\\base\\View->render(\'<span class=\"st...\', \'[<span class=\"s...\', Object(frontend\\controllers\\StudentController))\n#27 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/controllers/StudentController.php(44): yii\\base\\Controller->render(\'<span class=\"st...\', \'[<span class=\"s...\')\n#28 [internal function]: frontend\\controllers\\StudentController->actionIndex()\n#29 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/InlineAction.php(57): call_user_func_array(\'[<span class=\"t...\', \'[]\')\n#30 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Controller.php(156): yii\\base\\InlineAction->runWithParams(\'[]\')\n#31 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Module.php(523): yii\\base\\Controller->runAction(\'<span class=\"st...\', \'[]\')\n#32 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/web/Application.php(102): yii\\base\\Module->runAction(\'<span class=\"st...\', \'[]\')\n#33 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#34 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/web/index.php(22): yii\\base\\Application->run()\n#35 {main}'),
(51, 1, 'yii\\base\\UnknownMethodException', 1501703864.5692, '[frontend][/student]', 'exception \'yii\\base\\UnknownMethodException\' with message \'Calling unknown method: common\\models\\query\\UserQuery::addFilterWhere()\' in /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Component.php:290\nStack trace:\n#0 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/models/StudentSearch.php(82): yii\\base\\Component->__call(\'addFilterWhere\', Array)\n#1 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/models/StudentSearch.php(82): common\\models\\query\\UserQuery->addFilterWhere(Array)\n#2 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/controllers/StudentController.php(39): common\\models\\StudentSearch->search(Array)\n#3 [internal function]: frontend\\controllers\\StudentController->actionIndex()\n#4 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/InlineAction.php(57): call_user_func_array(Array, Array)\n#5 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#6 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Module.php(523): yii\\base\\Controller->runAction(\'\', Array)\n#7 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/web/Application.php(102): yii\\base\\Module->runAction(\'student\', Array)\n#8 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#9 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/web/index.php(22): yii\\base\\Application->run()\n#10 {main}'),
(52, 1, 'yii\\base\\UnknownMethodException', 1501703895.0331, '[frontend][/student]', 'exception \'yii\\base\\UnknownMethodException\' with message \'Calling unknown method: common\\models\\query\\UserQuery::addFilterWhere()\' in /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Component.php:290\nStack trace:\n#0 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/models/StudentSearch.php(82): yii\\base\\Component->__call(\'addFilterWhere\', Array)\n#1 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/models/StudentSearch.php(82): common\\models\\query\\UserQuery->addFilterWhere(Array)\n#2 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/controllers/StudentController.php(39): common\\models\\StudentSearch->search(Array)\n#3 [internal function]: frontend\\controllers\\StudentController->actionIndex()\n#4 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/InlineAction.php(57): call_user_func_array(Array, Array)\n#5 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#6 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Module.php(523): yii\\base\\Controller->runAction(\'\', Array)\n#7 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/web/Application.php(102): yii\\base\\Module->runAction(\'student\', Array)\n#8 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#9 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/web/index.php(22): yii\\base\\Application->run()\n#10 {main}');
INSERT INTO `system_log` (`id`, `level`, `category`, `log_time`, `prefix`, `message`) VALUES
(53, 1, 'yii\\db\\Exception', 1501703994.4131, '[frontend][/student]', 'exception \'yii\\base\\ErrorException\' with message \'Undefined offset: 1\' in /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/Command.php:282\nStack trace:\n#0 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/Command.php(282): yii\\base\\ErrorHandler->handleError(8, \'Undefined offse...\', \'/var/www/hamste...\', 282, Array)\n#1 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/Command.php(226): yii\\db\\Command->bindPendingParams()\n#2 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/Command.php(910): yii\\db\\Command->prepare(\'<span class=\"ke...\')\n#3 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/Command.php(388): yii\\db\\Command->queryInternal(\'<span class=\"st...\', \'<span class=\"nu...\')\n#4 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/Query.php(433): yii\\db\\Command->queryScalar()\n#5 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/ActiveQuery.php(339): yii\\db\\Query->queryScalar(\'<span class=\"st...\', Object(yii\\db\\Connection))\n#6 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/Query.php(319): yii\\db\\ActiveQuery->queryScalar(\'<span class=\"st...\', \'<span class=\"ke...\')\n#7 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/ActiveDataProvider.php(169): yii\\db\\Query->count(\'<span class=\"st...\', \'<span class=\"ke...\')\n#8 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(169): yii\\data\\ActiveDataProvider->prepareTotalCount()\n#9 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/ActiveDataProvider.php(106): yii\\data\\BaseDataProvider->getTotalCount()\n#10 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(101): yii\\data\\ActiveDataProvider->prepareModels()\n#11 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(114): yii\\data\\BaseDataProvider->prepare()\n#12 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(155): yii\\data\\BaseDataProvider->getModels()\n#13 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(189): yii\\data\\BaseDataProvider->getCount()\n#14 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(157): yii\\widgets\\BaseListView->renderSummary()\n#15 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/grid/GridView.php(316): yii\\widgets\\BaseListView->renderSection(\'<span class=\"st...\')\n#16 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(134): yii\\grid\\GridView->renderSection(\'<span class=\"st...\')\n#17 [internal function]: yii\\widgets\\BaseListView->yii\\widgets\\{closure}(\'[<span class=\"s...\')\n#18 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(137): preg_replace_callback(\'<span class=\"st...\', Object(Closure), \'<span class=\"st...\')\n#19 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/grid/GridView.php(291): yii\\widgets\\BaseListView->run()\n#20 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Widget.php(139): yii\\grid\\GridView->run()\n#21 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/views/student/index.php(42): yii\\base\\Widget::widget(\'[<span class=\"s...\')\n#22 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/View.php(330): require(\'/var/www/hamste...\')\n#23 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/View.php(250): yii\\base\\View->renderPhpFile(\'<span class=\"st...\', \'[<span class=\"s...\')\n#24 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/View.php(152): yii\\base\\View->renderFile(\'<span class=\"st...\', \'[<span class=\"s...\', Object(frontend\\controllers\\StudentController))\n#25 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Controller.php(381): yii\\base\\View->render(\'<span class=\"st...\', \'[<span class=\"s...\', Object(frontend\\controllers\\StudentController))\n#26 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/controllers/StudentController.php(44): yii\\base\\Controller->render(\'<span class=\"st...\', \'[<span class=\"s...\')\n#27 [internal function]: frontend\\controllers\\StudentController->actionIndex()\n#28 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/InlineAction.php(57): call_user_func_array(\'[<span class=\"t...\', \'[]\')\n#29 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Controller.php(156): yii\\base\\InlineAction->runWithParams(\'[]\')\n#30 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Module.php(523): yii\\base\\Controller->runAction(\'<span class=\"st...\', \'[]\')\n#31 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/web/Application.php(102): yii\\base\\Module->runAction(\'<span class=\"st...\', \'[]\')\n#32 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#33 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/web/index.php(22): yii\\base\\Application->run()\n#34 {main}\n\nNext exception \'yii\\db\\Exception\' with message \'Undefined offset: 1\nFailed to prepare SQL: SELECT COUNT(*) FROM `user` WHERE `id` = :qp0\' in /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/Command.php:230\nStack trace:\n#0 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/Command.php(910): yii\\db\\Command->prepare(\'<span class=\"ke...\')\n#1 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/Command.php(388): yii\\db\\Command->queryInternal(\'<span class=\"st...\', \'<span class=\"nu...\')\n#2 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/Query.php(433): yii\\db\\Command->queryScalar()\n#3 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/ActiveQuery.php(339): yii\\db\\Query->queryScalar(\'<span class=\"st...\', Object(yii\\db\\Connection))\n#4 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/db/Query.php(319): yii\\db\\ActiveQuery->queryScalar(\'<span class=\"st...\', \'<span class=\"ke...\')\n#5 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/ActiveDataProvider.php(169): yii\\db\\Query->count(\'<span class=\"st...\', \'<span class=\"ke...\')\n#6 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(169): yii\\data\\ActiveDataProvider->prepareTotalCount()\n#7 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/ActiveDataProvider.php(106): yii\\data\\BaseDataProvider->getTotalCount()\n#8 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(101): yii\\data\\ActiveDataProvider->prepareModels()\n#9 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(114): yii\\data\\BaseDataProvider->prepare()\n#10 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/data/BaseDataProvider.php(155): yii\\data\\BaseDataProvider->getModels()\n#11 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(189): yii\\data\\BaseDataProvider->getCount()\n#12 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(157): yii\\widgets\\BaseListView->renderSummary()\n#13 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/grid/GridView.php(316): yii\\widgets\\BaseListView->renderSection(\'<span class=\"st...\')\n#14 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(134): yii\\grid\\GridView->renderSection(\'<span class=\"st...\')\n#15 [internal function]: yii\\widgets\\BaseListView->yii\\widgets\\{closure}(\'[<span class=\"s...\')\n#16 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/widgets/BaseListView.php(137): preg_replace_callback(\'<span class=\"st...\', Object(Closure), \'<span class=\"st...\')\n#17 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/grid/GridView.php(291): yii\\widgets\\BaseListView->run()\n#18 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Widget.php(139): yii\\grid\\GridView->run()\n#19 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/views/student/index.php(42): yii\\base\\Widget::widget(\'[<span class=\"s...\')\n#20 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/View.php(330): require(\'/var/www/hamste...\')\n#21 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/View.php(250): yii\\base\\View->renderPhpFile(\'<span class=\"st...\', \'[<span class=\"s...\')\n#22 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/View.php(152): yii\\base\\View->renderFile(\'<span class=\"st...\', \'[<span class=\"s...\', Object(frontend\\controllers\\StudentController))\n#23 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Controller.php(381): yii\\base\\View->render(\'<span class=\"st...\', \'[<span class=\"s...\', Object(frontend\\controllers\\StudentController))\n#24 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/controllers/StudentController.php(44): yii\\base\\Controller->render(\'<span class=\"st...\', \'[<span class=\"s...\')\n#25 [internal function]: frontend\\controllers\\StudentController->actionIndex()\n#26 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/InlineAction.php(57): call_user_func_array(\'[<span class=\"t...\', \'[]\')\n#27 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Controller.php(156): yii\\base\\InlineAction->runWithParams(\'[]\')\n#28 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Module.php(523): yii\\base\\Controller->runAction(\'<span class=\"st...\', \'[]\')\n#29 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/web/Application.php(102): yii\\base\\Module->runAction(\'<span class=\"st...\', \'[]\')\n#30 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#31 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/web/index.php(22): yii\\base\\Application->run()\n#32 {main}\nAdditional Information:\n'),
(54, 1, 'yii\\base\\ErrorException:4', 1501704737.6338, '[frontend][/teacher/index]', 'exception \'yii\\base\\ErrorException\' with message \'syntax error, unexpected \',\'\' in /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/models/TeacherSearch.php:77\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleFatalError()\n#1 {main}'),
(55, 1, 'yii\\base\\UnknownClassException', 1501704816.381, '[frontend][/students-class/index]', 'exception \'yii\\base\\UnknownClassException\' with message \'Unable to find \'common\\models\\ClassQuery\' in file: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/models/ClassQuery.php. Namespace missing?\' in /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/BaseYii.php:295\nStack trace:\n#0 [internal function]: yii\\BaseYii::autoload(\'common\\\\models\\\\C...\')\n#1 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/models/StudentsClass.php(58): spl_autoload_call(\'common\\\\models\\\\C...\')\n#2 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/models/StudentsClassSearch.php(44): common\\models\\StudentsClass::find()\n#3 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/controllers/StudentsClassController.php(39): common\\models\\StudentsClassSearch->search(Array)\n#4 [internal function]: frontend\\controllers\\StudentsClassController->actionIndex()\n#5 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/InlineAction.php(57): call_user_func_array(Array, Array)\n#6 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#7 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Module.php(523): yii\\base\\Controller->runAction(\'index\', Array)\n#8 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/web/Application.php(102): yii\\base\\Module->runAction(\'students-class/...\', Array)\n#9 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/vendor/yiisoft/yii2/base/Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#10 /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/frontend/web/index.php(22): yii\\base\\Application->run()\n#11 {main}'),
(56, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501704854.6854, '[frontend][/students-class/index]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(57, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501704873.8428, '[frontend][/lesson/index]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(58, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501704892.4623, '[frontend][/students-class/index]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(59, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501704895.392, '[frontend][/subject/index]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(60, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501705422.1038, '[frontend][/subject/create]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(61, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501705429.8276, '[frontend][/subject/view?id=1]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(62, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501705466.028, '[frontend][/subject/view?id=1]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(63, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501705523.951, '[frontend][/subject/view?id=1]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(64, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501705529.9134, '[frontend][/lesson/index]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(65, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501705602.7338, '[frontend][/subject/index]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(66, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501705606.6988, '[frontend][/lesson/index]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(67, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501705611.1322, '[frontend][/students-class/index]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(68, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501705612.9185, '[frontend][/students-class/create]', 'The message file for category \'app\' does not exist: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru-RU/app.php Fallback file does not exist as well: /var/www/hamsterlanduz/data/www/maktapp.hamsterland.uz/common/messages/ru/app.php'),
(69, 1, 'yii\\base\\ErrorException:2', 1501792126.0718, '[frontend][/]', 'yii\\base\\ErrorException: symlink(): Cannot create symlink, error code(1314) in C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php:522\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleError(2, \'symlink(): Cann...\', \'C:\\\\htdocs\\\\makta...\', 522, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(522): symlink(\'C:\\\\htdocs\\\\makta...\', \'C:\\\\htdocs\\\\makta...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(460): yii\\web\\AssetManager->publishDirectory(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetBundle.php(185): yii\\web\\AssetManager->publish(\'C:\\\\htdocs\\\\makta...\', Array)\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(268): yii\\web\\AssetBundle->publish(Object(yii\\web\\AssetManager))\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(239): yii\\web\\AssetManager->loadBundle(\'yii\\\\bootstrap\\\\B...\', Array, true)\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\View.php(286): yii\\web\\AssetManager->getBundle(\'yii\\\\bootstrap\\\\B...\')\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetBundle.php(125): yii\\web\\View->registerAssetBundle(\'yii\\\\bootstrap\\\\B...\')\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-bootstrap\\BootstrapWidgetTrait.php(73): yii\\web\\AssetBundle::register(Object(yii\\web\\View))\n#9 C:\\htdocs\\maktapp.loc\\common\\widgets\\DbCarousel.php(82): yii\\bootstrap\\Widget->registerPlugin(\'carousel\')\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Widget.php(139): common\\widgets\\DbCarousel->run()\n#11 C:\\htdocs\\maktapp.loc\\frontend\\views\\site\\index.php(8): yii\\base\\Widget::widget(Array)\n#12 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#13 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#14 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, Object(frontend\\controllers\\SiteController))\n#15 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(381): yii\\base\\View->render(\'index\', Array, Object(frontend\\controllers\\SiteController))\n#16 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\SiteController.php(35): yii\\base\\Controller->render(\'index\')\n#17 [internal function]: frontend\\controllers\\SiteController->actionIndex()\n#18 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#19 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#20 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'index\', Array)\n#21 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'\', Array)\n#22 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#23 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#24 {main}'),
(70, 1, 'yii\\base\\ErrorException:2', 1501792229.6115, '[frontend][/]', 'yii\\base\\ErrorException: symlink(): Cannot create symlink, error code(1314) in C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php:522\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleError(2, \'symlink(): Cann...\', \'C:\\\\htdocs\\\\makta...\', 522, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(522): symlink(\'C:\\\\htdocs\\\\makta...\', \'C:\\\\htdocs\\\\makta...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(460): yii\\web\\AssetManager->publishDirectory(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetBundle.php(185): yii\\web\\AssetManager->publish(\'C:\\\\htdocs\\\\makta...\', Array)\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(268): yii\\web\\AssetBundle->publish(Object(yii\\web\\AssetManager))\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(239): yii\\web\\AssetManager->loadBundle(\'yii\\\\bootstrap\\\\B...\', Array, true)\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\View.php(286): yii\\web\\AssetManager->getBundle(\'yii\\\\bootstrap\\\\B...\')\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetBundle.php(125): yii\\web\\View->registerAssetBundle(\'yii\\\\bootstrap\\\\B...\')\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-bootstrap\\BootstrapWidgetTrait.php(73): yii\\web\\AssetBundle::register(Object(yii\\web\\View))\n#9 C:\\htdocs\\maktapp.loc\\common\\widgets\\DbCarousel.php(82): yii\\bootstrap\\Widget->registerPlugin(\'carousel\')\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Widget.php(139): common\\widgets\\DbCarousel->run()\n#11 C:\\htdocs\\maktapp.loc\\frontend\\views\\site\\index.php(8): yii\\base\\Widget::widget(Array)\n#12 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#13 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#14 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, Object(frontend\\controllers\\SiteController))\n#15 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(381): yii\\base\\View->render(\'index\', Array, Object(frontend\\controllers\\SiteController))\n#16 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\SiteController.php(35): yii\\base\\Controller->render(\'index\')\n#17 [internal function]: frontend\\controllers\\SiteController->actionIndex()\n#18 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#19 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#20 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'index\', Array)\n#21 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'\', Array)\n#22 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#23 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#24 {main}'),
(71, 1, 'yii\\base\\ErrorException:2', 1501792315.3601, '[frontend][/]', 'yii\\base\\ErrorException: symlink(): Cannot create symlink, error code(1314) in C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php:522\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleError(2, \'symlink(): Cann...\', \'C:\\\\htdocs\\\\makta...\', 522, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(522): symlink(\'C:\\\\htdocs\\\\makta...\', \'C:\\\\htdocs\\\\makta...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(460): yii\\web\\AssetManager->publishDirectory(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetBundle.php(185): yii\\web\\AssetManager->publish(\'C:\\\\htdocs\\\\makta...\', Array)\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(268): yii\\web\\AssetBundle->publish(Object(yii\\web\\AssetManager))\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(239): yii\\web\\AssetManager->loadBundle(\'yii\\\\bootstrap\\\\B...\', Array, true)\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\View.php(286): yii\\web\\AssetManager->getBundle(\'yii\\\\bootstrap\\\\B...\')\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetBundle.php(125): yii\\web\\View->registerAssetBundle(\'yii\\\\bootstrap\\\\B...\')\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-bootstrap\\BootstrapWidgetTrait.php(73): yii\\web\\AssetBundle::register(Object(yii\\web\\View))\n#9 C:\\htdocs\\maktapp.loc\\common\\widgets\\DbCarousel.php(82): yii\\bootstrap\\Widget->registerPlugin(\'carousel\')\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Widget.php(139): common\\widgets\\DbCarousel->run()\n#11 C:\\htdocs\\maktapp.loc\\frontend\\views\\site\\index.php(8): yii\\base\\Widget::widget(Array)\n#12 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#13 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#14 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, Object(frontend\\controllers\\SiteController))\n#15 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(381): yii\\base\\View->render(\'index\', Array, Object(frontend\\controllers\\SiteController))\n#16 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\SiteController.php(35): yii\\base\\Controller->render(\'index\')\n#17 [internal function]: frontend\\controllers\\SiteController->actionIndex()\n#18 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#19 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#20 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'index\', Array)\n#21 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'\', Array)\n#22 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#23 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#24 {main}'),
(72, 1, 'yii\\base\\ErrorException:2', 1501792361.6455, '[frontend][/]', 'yii\\base\\ErrorException: symlink(): Cannot create symlink, error code(1314) in C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php:522\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleError(2, \'symlink(): Cann...\', \'C:\\\\htdocs\\\\makta...\', 522, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(522): symlink(\'C:\\\\htdocs\\\\makta...\', \'C:\\\\htdocs\\\\makta...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(460): yii\\web\\AssetManager->publishDirectory(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetBundle.php(185): yii\\web\\AssetManager->publish(\'C:\\\\htdocs\\\\makta...\', Array)\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(268): yii\\web\\AssetBundle->publish(Object(yii\\web\\AssetManager))\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(239): yii\\web\\AssetManager->loadBundle(\'yii\\\\bootstrap\\\\B...\', Array, true)\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\View.php(286): yii\\web\\AssetManager->getBundle(\'yii\\\\bootstrap\\\\B...\')\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetBundle.php(125): yii\\web\\View->registerAssetBundle(\'yii\\\\bootstrap\\\\B...\')\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-bootstrap\\BootstrapWidgetTrait.php(73): yii\\web\\AssetBundle::register(Object(yii\\web\\View))\n#9 C:\\htdocs\\maktapp.loc\\common\\widgets\\DbCarousel.php(82): yii\\bootstrap\\Widget->registerPlugin(\'carousel\')\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Widget.php(139): common\\widgets\\DbCarousel->run()\n#11 C:\\htdocs\\maktapp.loc\\frontend\\views\\site\\index.php(8): yii\\base\\Widget::widget(Array)\n#12 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#13 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#14 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, Object(frontend\\controllers\\SiteController))\n#15 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(381): yii\\base\\View->render(\'index\', Array, Object(frontend\\controllers\\SiteController))\n#16 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\SiteController.php(35): yii\\base\\Controller->render(\'index\')\n#17 [internal function]: frontend\\controllers\\SiteController->actionIndex()\n#18 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#19 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#20 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'index\', Array)\n#21 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'\', Array)\n#22 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#23 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#24 {main}'),
(73, 1, 'yii\\base\\ErrorException:2', 1501792368.3019, '[frontend][/]', 'yii\\base\\ErrorException: symlink(): Cannot create symlink, error code(1314) in C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php:522\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleError(2, \'symlink(): Cann...\', \'C:\\\\htdocs\\\\makta...\', 522, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(522): symlink(\'C:\\\\htdocs\\\\makta...\', \'C:\\\\htdocs\\\\makta...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(460): yii\\web\\AssetManager->publishDirectory(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetBundle.php(185): yii\\web\\AssetManager->publish(\'C:\\\\htdocs\\\\makta...\', Array)\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(268): yii\\web\\AssetBundle->publish(Object(yii\\web\\AssetManager))\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(239): yii\\web\\AssetManager->loadBundle(\'yii\\\\bootstrap\\\\B...\', Array, true)\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\View.php(286): yii\\web\\AssetManager->getBundle(\'yii\\\\bootstrap\\\\B...\')\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetBundle.php(125): yii\\web\\View->registerAssetBundle(\'yii\\\\bootstrap\\\\B...\')\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-bootstrap\\BootstrapWidgetTrait.php(73): yii\\web\\AssetBundle::register(Object(yii\\web\\View))\n#9 C:\\htdocs\\maktapp.loc\\common\\widgets\\DbCarousel.php(82): yii\\bootstrap\\Widget->registerPlugin(\'carousel\')\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Widget.php(139): common\\widgets\\DbCarousel->run()\n#11 C:\\htdocs\\maktapp.loc\\frontend\\views\\site\\index.php(8): yii\\base\\Widget::widget(Array)\n#12 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#13 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#14 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, Object(frontend\\controllers\\SiteController))\n#15 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(381): yii\\base\\View->render(\'index\', Array, Object(frontend\\controllers\\SiteController))\n#16 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\SiteController.php(35): yii\\base\\Controller->render(\'index\')\n#17 [internal function]: frontend\\controllers\\SiteController->actionIndex()\n#18 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#19 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#20 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'index\', Array)\n#21 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'\', Array)\n#22 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#23 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#24 {main}'),
(74, 1, 'yii\\base\\ErrorException:2', 1501792419.232, '[frontend][/]', 'yii\\base\\ErrorException: symlink(): Cannot create symlink, error code(1314) in C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php:522\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleError(2, \'symlink(): Cann...\', \'C:\\\\htdocs\\\\makta...\', 522, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(522): symlink(\'C:\\\\htdocs\\\\makta...\', \'C:\\\\htdocs\\\\makta...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(460): yii\\web\\AssetManager->publishDirectory(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetBundle.php(185): yii\\web\\AssetManager->publish(\'C:\\\\htdocs\\\\makta...\', Array)\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(268): yii\\web\\AssetBundle->publish(Object(yii\\web\\AssetManager))\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(239): yii\\web\\AssetManager->loadBundle(\'yii\\\\bootstrap\\\\B...\', Array, true)\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\View.php(286): yii\\web\\AssetManager->getBundle(\'yii\\\\bootstrap\\\\B...\')\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetBundle.php(125): yii\\web\\View->registerAssetBundle(\'yii\\\\bootstrap\\\\B...\')\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-bootstrap\\BootstrapWidgetTrait.php(73): yii\\web\\AssetBundle::register(Object(yii\\web\\View))\n#9 C:\\htdocs\\maktapp.loc\\common\\widgets\\DbCarousel.php(82): yii\\bootstrap\\Widget->registerPlugin(\'carousel\')\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Widget.php(139): common\\widgets\\DbCarousel->run()\n#11 C:\\htdocs\\maktapp.loc\\frontend\\views\\site\\index.php(8): yii\\base\\Widget::widget(Array)\n#12 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#13 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#14 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, Object(frontend\\controllers\\SiteController))\n#15 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(381): yii\\base\\View->render(\'index\', Array, Object(frontend\\controllers\\SiteController))\n#16 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\SiteController.php(35): yii\\base\\Controller->render(\'index\')\n#17 [internal function]: frontend\\controllers\\SiteController->actionIndex()\n#18 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#19 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#20 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'index\', Array)\n#21 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'\', Array)\n#22 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#23 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#24 {main}'),
(75, 1, 'yii\\base\\ErrorException:2', 1501792426.4524, '[frontend][/]', 'yii\\base\\ErrorException: symlink(): Cannot create symlink, error code(1314) in C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php:522\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleError(2, \'symlink(): Cann...\', \'C:\\\\htdocs\\\\makta...\', 522, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(522): symlink(\'C:\\\\htdocs\\\\makta...\', \'C:\\\\htdocs\\\\makta...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(460): yii\\web\\AssetManager->publishDirectory(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetBundle.php(185): yii\\web\\AssetManager->publish(\'C:\\\\htdocs\\\\makta...\', Array)\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(268): yii\\web\\AssetBundle->publish(Object(yii\\web\\AssetManager))\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(239): yii\\web\\AssetManager->loadBundle(\'yii\\\\bootstrap\\\\B...\', Array, true)\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\View.php(286): yii\\web\\AssetManager->getBundle(\'yii\\\\bootstrap\\\\B...\')\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetBundle.php(125): yii\\web\\View->registerAssetBundle(\'yii\\\\bootstrap\\\\B...\')\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-bootstrap\\BootstrapWidgetTrait.php(73): yii\\web\\AssetBundle::register(Object(yii\\web\\View))\n#9 C:\\htdocs\\maktapp.loc\\common\\widgets\\DbCarousel.php(82): yii\\bootstrap\\Widget->registerPlugin(\'carousel\')\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Widget.php(139): common\\widgets\\DbCarousel->run()\n#11 C:\\htdocs\\maktapp.loc\\frontend\\views\\site\\index.php(8): yii\\base\\Widget::widget(Array)\n#12 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#13 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#14 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, Object(frontend\\controllers\\SiteController))\n#15 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(381): yii\\base\\View->render(\'index\', Array, Object(frontend\\controllers\\SiteController))\n#16 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\SiteController.php(35): yii\\base\\Controller->render(\'index\')\n#17 [internal function]: frontend\\controllers\\SiteController->actionIndex()\n#18 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#19 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#20 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'index\', Array)\n#21 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'\', Array)\n#22 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#23 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#24 {main}'),
(76, 1, 'yii\\base\\ErrorException:2', 1501792442.8654, '[frontend][/]', 'yii\\base\\ErrorException: symlink(): Cannot create symlink, error code(1314) in C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php:522\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleError(2, \'symlink(): Cann...\', \'C:\\\\htdocs\\\\makta...\', 522, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(522): symlink(\'C:\\\\htdocs\\\\makta...\', \'C:\\\\htdocs\\\\makta...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(460): yii\\web\\AssetManager->publishDirectory(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetBundle.php(185): yii\\web\\AssetManager->publish(\'C:\\\\htdocs\\\\makta...\', Array)\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(268): yii\\web\\AssetBundle->publish(Object(yii\\web\\AssetManager))\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetManager.php(239): yii\\web\\AssetManager->loadBundle(\'yii\\\\bootstrap\\\\B...\', Array, true)\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\View.php(286): yii\\web\\AssetManager->getBundle(\'yii\\\\bootstrap\\\\B...\')\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\AssetBundle.php(125): yii\\web\\View->registerAssetBundle(\'yii\\\\bootstrap\\\\B...\')\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-bootstrap\\BootstrapWidgetTrait.php(73): yii\\web\\AssetBundle::register(Object(yii\\web\\View))\n#9 C:\\htdocs\\maktapp.loc\\common\\widgets\\DbCarousel.php(82): yii\\bootstrap\\Widget->registerPlugin(\'carousel\')\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Widget.php(139): common\\widgets\\DbCarousel->run()\n#11 C:\\htdocs\\maktapp.loc\\frontend\\views\\site\\index.php(8): yii\\base\\Widget::widget(Array)\n#12 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#13 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#14 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, Object(frontend\\controllers\\SiteController))\n#15 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(381): yii\\base\\View->render(\'index\', Array, Object(frontend\\controllers\\SiteController))\n#16 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\SiteController.php(35): yii\\base\\Controller->render(\'index\')\n#17 [internal function]: frontend\\controllers\\SiteController->actionIndex()\n#18 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#19 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#20 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'index\', Array)\n#21 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'\', Array)\n#22 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#23 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#24 {main}'),
(77, 2, 'yii\\log\\Dispatcher::dispatch', 1501793192.9645, '[backend][/]', 'Unable to send log via yii\\debug\\LogTarget: PHP Notice \'yii\\base\\ErrorException\' with message \'unserialize(): Error at offset 22 of 17513 bytes\' \n\nin C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php:88\n\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleError(8, \'unserialize(): ...\', \'C:\\\\htdocs\\\\makta...\', 88, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(88): unserialize(\'a:60:{i:5982199...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(63): yii\\debug\\LogTarget->updateIndexFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(118): yii\\debug\\LogTarget->export()\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Dispatcher.php(188): yii\\debug\\LogTarget->collect(Array, true)\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Logger.php(177): yii\\log\\Dispatcher->dispatch(Array, true)\n#6 [internal function]: yii\\log\\Logger->flush(true)\n#7 {main}'),
(78, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1501793668.56, '[frontend][/subject/index]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(79, 1, 'yii\\base\\UnknownPropertyException', 1502027445.3265, '[frontend][/students-class/create]', 'yii\\base\\UnknownPropertyException: Getting unknown property: yii\\web\\User::school_id in C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Component.php:147\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\StudentsClassController.php(71): yii\\base\\Component->__get(\'school_id\')\n#1 [internal function]: frontend\\controllers\\StudentsClassController->actionCreate()\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'create\', Array)\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'students-class/...\', Array)\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#7 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#8 {main}'),
(80, 1, 'yii\\base\\InvalidConfigException', 1502109457.5064, '[frontend][/js/select2.min.js]', 'yii\\base\\InvalidConfigException: yii\\web\\Request::cookieValidationKey must be configured with a secret key. in C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php:1292\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php(1274): yii\\web\\Request->loadCookies()\n#1 C:\\htdocs\\maktapp.loc\\common\\behaviors\\LocaleBehavior.php(39): yii\\web\\Request->getCookies()\n#2 [internal function]: common\\behaviors\\LocaleBehavior->beforeRequest(Object(yii\\base\\Event))\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Component.php(545): call_user_func(Array, Object(yii\\base\\Event))\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(377): yii\\base\\Component->trigger(\'beforeRequest\')\n#5 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#6 {main}');
INSERT INTO `system_log` (`id`, `level`, `category`, `log_time`, `prefix`, `message`) VALUES
(81, 2, 'yii\\log\\Dispatcher::dispatch', 1502109457.7578, '[frontend][/js/select2.min.js]', 'Unable to send log via yii\\debug\\LogTarget: Exception (Invalid Configuration) \'yii\\base\\InvalidConfigException\' with message \'yii\\web\\Request::cookieValidationKey must be configured with a secret key.\' \n\nin C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php:1292\n\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php(1274): yii\\web\\Request->loadCookies()\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\User.php(512): yii\\web\\Request->getCookies()\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\User.php(676): yii\\web\\User->renewIdentityCookie()\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\User.php(188): yii\\web\\User->renewAuthStatus()\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Component.php(132): yii\\web\\User->getIdentity()\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\panels\\UserPanel.php(54): yii\\base\\Component->__get(\'identity\')\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(54): yii\\debug\\panels\\UserPanel->save()\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(118): yii\\debug\\LogTarget->export()\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Dispatcher.php(188): yii\\debug\\LogTarget->collect(Array, true)\n#9 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Logger.php(177): yii\\log\\Dispatcher->dispatch(Array, true)\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\ErrorHandler.php(113): yii\\log\\Logger->flush(true)\n#11 [internal function]: yii\\base\\ErrorHandler->handleException(Object(yii\\base\\InvalidConfigException))\n#12 {main}'),
(82, 1, 'yii\\web\\Session::open', 1502109457.743, '[frontend][/js/select2.min.js]', 'session_start(): Cannot send session cache limiter - headers already sent (output started at C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Response.php:412)'),
(83, 1, 'yii\\base\\ErrorException:8', 1502110149.212, '[frontend][/students-class/index]', 'yii\\base\\ErrorException: Use of undefined constant php - assumed \'php\' in C:\\htdocs\\maktapp.loc\\frontend\\views\\students-class\\index.php:23\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\frontend\\views\\students-class\\index.php(23): yii\\base\\ErrorHandler->handleError(8, \'Use of undefine...\', \'C:\\\\htdocs\\\\makta...\', 23, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, Object(frontend\\controllers\\StudentsClassController))\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(381): yii\\base\\View->render(\'index\', Array, Object(frontend\\controllers\\StudentsClassController))\n#5 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\StudentsClassController.php(44): yii\\base\\Controller->render(\'index\', Array)\n#6 [internal function]: frontend\\controllers\\StudentsClassController->actionIndex()\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#9 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'index\', Array)\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'students-class/...\', Array)\n#11 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#12 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#13 {main}'),
(84, 1, 'yii\\base\\InvalidConfigException', 1502110164.1311, '[frontend][/images/registr.png]', 'yii\\base\\InvalidConfigException: yii\\web\\Request::cookieValidationKey must be configured with a secret key. in C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php:1292\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php(1274): yii\\web\\Request->loadCookies()\n#1 C:\\htdocs\\maktapp.loc\\common\\behaviors\\LocaleBehavior.php(39): yii\\web\\Request->getCookies()\n#2 [internal function]: common\\behaviors\\LocaleBehavior->beforeRequest(Object(yii\\base\\Event))\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Component.php(545): call_user_func(Array, Object(yii\\base\\Event))\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(377): yii\\base\\Component->trigger(\'beforeRequest\')\n#5 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#6 {main}'),
(85, 2, 'yii\\log\\Dispatcher::dispatch', 1502110164.503, '[frontend][/images/registr.png]', 'Unable to send log via yii\\debug\\LogTarget: Exception (Invalid Configuration) \'yii\\base\\InvalidConfigException\' with message \'yii\\web\\Request::cookieValidationKey must be configured with a secret key.\' \n\nin C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php:1292\n\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php(1274): yii\\web\\Request->loadCookies()\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\User.php(512): yii\\web\\Request->getCookies()\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\User.php(676): yii\\web\\User->renewIdentityCookie()\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\User.php(188): yii\\web\\User->renewAuthStatus()\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Component.php(132): yii\\web\\User->getIdentity()\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\panels\\UserPanel.php(54): yii\\base\\Component->__get(\'identity\')\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(54): yii\\debug\\panels\\UserPanel->save()\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(118): yii\\debug\\LogTarget->export()\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Dispatcher.php(188): yii\\debug\\LogTarget->collect(Array, true)\n#9 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Logger.php(177): yii\\log\\Dispatcher->dispatch(Array, true)\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\ErrorHandler.php(113): yii\\log\\Logger->flush(true)\n#11 [internal function]: yii\\base\\ErrorHandler->handleException(Object(yii\\base\\InvalidConfigException))\n#12 {main}'),
(86, 1, 'yii\\web\\Session::open', 1502110164.4838, '[frontend][/images/registr.png]', 'session_start(): Cannot send session cache limiter - headers already sent (output started at C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Response.php:412)'),
(87, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502117475.385, '[frontend][/subject/index]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(88, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502117483.9582, '[frontend][/subject/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(89, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502117495.7492, '[frontend][/subject/2]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(90, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502117499.1359, '[frontend][/subject/index]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(91, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502117501.5709, '[frontend][/subject/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(92, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502117510.555, '[frontend][/subject/3]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(93, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502117514.3514, '[frontend][/subject/index]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(94, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502117517.3684, '[frontend][/subject/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(95, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502117525.9306, '[frontend][/subject/4]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(96, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502117543.112, '[frontend][/lesson/index]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(97, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502117553.7908, '[frontend][/lesson/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(98, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502117585.4273, '[frontend][/students-class/view/?id=2]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(99, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502117918.0603, '[frontend][/students-class/view/?id=3]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(100, 1, 'yii\\base\\InvalidConfigException', 1502117918.8616, '[frontend][/fonts/sf-ui-text-regular-webfont.ttf]', 'yii\\base\\InvalidConfigException: yii\\web\\Request::cookieValidationKey must be configured with a secret key. in C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php:1292\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php(1274): yii\\web\\Request->loadCookies()\n#1 C:\\htdocs\\maktapp.loc\\common\\behaviors\\LocaleBehavior.php(39): yii\\web\\Request->getCookies()\n#2 [internal function]: common\\behaviors\\LocaleBehavior->beforeRequest(Object(yii\\base\\Event))\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Component.php(545): call_user_func(Array, Object(yii\\base\\Event))\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(377): yii\\base\\Component->trigger(\'beforeRequest\')\n#5 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#6 {main}'),
(101, 2, 'yii\\log\\Dispatcher::dispatch', 1502117919.3725, '[frontend][/fonts/sf-ui-text-regular-webfont.ttf]', 'Unable to send log via yii\\debug\\LogTarget: Exception (Invalid Configuration) \'yii\\base\\InvalidConfigException\' with message \'yii\\web\\Request::cookieValidationKey must be configured with a secret key.\' \n\nin C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php:1292\n\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php(1274): yii\\web\\Request->loadCookies()\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\User.php(512): yii\\web\\Request->getCookies()\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\User.php(676): yii\\web\\User->renewIdentityCookie()\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\User.php(188): yii\\web\\User->renewAuthStatus()\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Component.php(132): yii\\web\\User->getIdentity()\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\panels\\UserPanel.php(54): yii\\base\\Component->__get(\'identity\')\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(54): yii\\debug\\panels\\UserPanel->save()\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(118): yii\\debug\\LogTarget->export()\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Dispatcher.php(188): yii\\debug\\LogTarget->collect(Array, true)\n#9 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Logger.php(177): yii\\log\\Dispatcher->dispatch(Array, true)\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\ErrorHandler.php(113): yii\\log\\Logger->flush(true)\n#11 [internal function]: yii\\base\\ErrorHandler->handleException(Object(yii\\base\\InvalidConfigException))\n#12 {main}'),
(102, 1, 'yii\\web\\Session::open', 1502117919.3239, '[frontend][/fonts/sf-ui-text-regular-webfont.ttf]', 'session_start(): Cannot send session cache limiter - headers already sent (output started at C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Response.php:412)'),
(103, 1, 'yii\\base\\ErrorException:8', 1502121141.2424, '[frontend][/students-class/students]', 'yii\\base\\ErrorException: Undefined variable: students in C:\\htdocs\\maktapp.loc\\frontend\\views\\students-class\\partial-index.php:28\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\frontend\\views\\students-class\\partial-index.php(28): yii\\base\\ErrorHandler->handleError(8, \'Undefined varia...\', \'C:\\\\htdocs\\\\makta...\', 28, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\View.php(212): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, Object(frontend\\controllers\\StudentsClassController))\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Controller.php(49): yii\\web\\View->renderAjax(\'partial-index\', Array, Object(frontend\\controllers\\StudentsClassController))\n#5 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\StudentsClassController.php(78): yii\\web\\Controller->renderAjax(\'partial-index\', Array)\n#6 [internal function]: frontend\\controllers\\StudentsClassController->actionStudents()\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#9 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'students\', Array)\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'students-class/...\', Array)\n#11 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#12 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#13 {main}'),
(104, 1, 'yii\\base\\InvalidConfigException', 1502121167.9545, '[frontend][/images/circle.jpg]', 'yii\\base\\InvalidConfigException: yii\\web\\Request::cookieValidationKey must be configured with a secret key. in C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php:1292\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php(1274): yii\\web\\Request->loadCookies()\n#1 C:\\htdocs\\maktapp.loc\\common\\behaviors\\LocaleBehavior.php(39): yii\\web\\Request->getCookies()\n#2 [internal function]: common\\behaviors\\LocaleBehavior->beforeRequest(Object(yii\\base\\Event))\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Component.php(545): call_user_func(Array, Object(yii\\base\\Event))\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(377): yii\\base\\Component->trigger(\'beforeRequest\')\n#5 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#6 {main}'),
(105, 2, 'yii\\log\\Dispatcher::dispatch', 1502121168.5158, '[frontend][/images/circle.jpg]', 'Unable to send log via yii\\debug\\LogTarget: Exception (Invalid Configuration) \'yii\\base\\InvalidConfigException\' with message \'yii\\web\\Request::cookieValidationKey must be configured with a secret key.\' \n\nin C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php:1292\n\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php(1274): yii\\web\\Request->loadCookies()\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\User.php(512): yii\\web\\Request->getCookies()\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\User.php(676): yii\\web\\User->renewIdentityCookie()\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\User.php(188): yii\\web\\User->renewAuthStatus()\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Component.php(132): yii\\web\\User->getIdentity()\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\panels\\UserPanel.php(54): yii\\base\\Component->__get(\'identity\')\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(54): yii\\debug\\panels\\UserPanel->save()\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(118): yii\\debug\\LogTarget->export()\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Dispatcher.php(188): yii\\debug\\LogTarget->collect(Array, true)\n#9 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Logger.php(177): yii\\log\\Dispatcher->dispatch(Array, true)\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\ErrorHandler.php(113): yii\\log\\Logger->flush(true)\n#11 [internal function]: yii\\base\\ErrorHandler->handleException(Object(yii\\base\\InvalidConfigException))\n#12 {main}'),
(106, 1, 'yii\\web\\Session::open', 1502121168.4515, '[frontend][/images/circle.jpg]', 'session_start(): Cannot send session cache limiter - headers already sent (output started at C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Response.php:412)'),
(107, 1, 'yii\\base\\ErrorException:8', 1502121171.0168, '[frontend][/students-class/students]', 'yii\\base\\ErrorException: Undefined variable: students in C:\\htdocs\\maktapp.loc\\frontend\\views\\students-class\\partial-index.php:28\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\frontend\\views\\students-class\\partial-index.php(28): yii\\base\\ErrorHandler->handleError(8, \'Undefined varia...\', \'C:\\\\htdocs\\\\makta...\', 28, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\View.php(212): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, Object(frontend\\controllers\\StudentsClassController))\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Controller.php(49): yii\\web\\View->renderAjax(\'partial-index\', Array, Object(frontend\\controllers\\StudentsClassController))\n#5 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\StudentsClassController.php(78): yii\\web\\Controller->renderAjax(\'partial-index\', Array)\n#6 [internal function]: frontend\\controllers\\StudentsClassController->actionStudents()\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#9 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'students\', Array)\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'students-class/...\', Array)\n#11 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#12 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#13 {main}'),
(108, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502121752.098, '[frontend][/subject/index]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(109, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502121755.1546, '[frontend][/lesson/index]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(110, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502121757.1595, '[frontend][/lesson/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(111, 1, 'yii\\base\\UnknownPropertyException', 1502184442.6979, '[frontend][/lesson/create]', 'yii\\base\\UnknownPropertyException: Getting unknown property: yii\\web\\User::school_id in C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Component.php:147\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\common\\models\\StudentsClass.php(68): yii\\base\\Component->__get(\'school_id\')\n#1 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\LessonController.php(79): common\\models\\StudentsClass::findAllBySchool()\n#2 [internal function]: frontend\\controllers\\LessonController->actionCreate()\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'create\', Array)\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'lesson/create\', Array)\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#8 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#9 {main}'),
(112, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502184447.837, '[frontend][/subject/index]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(113, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502196584.3156, '[frontend][/lesson/index]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(114, 1, 'yii\\base\\UnknownPropertyException', 1502196594.0841, '[frontend][/lesson/create]', 'yii\\base\\UnknownPropertyException: Getting unknown property: yii\\web\\User::school_id in C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Component.php:147\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\common\\models\\StudentsClass.php(68): yii\\base\\Component->__get(\'school_id\')\n#1 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\LessonController.php(79): common\\models\\StudentsClass::findAllBySchool()\n#2 [internal function]: frontend\\controllers\\LessonController->actionCreate()\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'create\', Array)\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'lesson/create\', Array)\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#8 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#9 {main}'),
(115, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502196882.7263, '[frontend][/lesson/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(116, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502197237.438, '[frontend][/lesson/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(117, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502197267.4366, '[frontend][/lesson/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(118, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502197350.6506, '[frontend][/lesson/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(119, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502198548.409, '[frontend][/lesson/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(120, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502198584.2153, '[frontend][/lesson/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(121, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502201504.0678, '[frontend][/lesson/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(122, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502201535.3578, '[frontend][/lesson/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(123, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502201540.6436, '[frontend][/quarter/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(124, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502202201.2431, '[frontend][/quarter/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(125, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502202255.6656, '[frontend][/quarter/1]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(126, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502202481.5394, '[frontend][/quarter/update/1]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(127, 1, 'yii\\base\\ErrorException:8', 1502202481.5455, '[frontend][/quarter/update/1]', 'yii\\base\\ErrorException: Undefined variable: years in C:\\htdocs\\maktapp.loc\\frontend\\views\\quarter\\_form.php:19\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\frontend\\views\\quarter\\_form.php(19): yii\\base\\ErrorHandler->handleError(8, \'Undefined varia...\', \'C:\\\\htdocs\\\\makta...\', 19, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, NULL)\n#4 C:\\htdocs\\maktapp.loc\\frontend\\views\\quarter\\update.php(20): yii\\base\\View->render(\'_form\', Array)\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, Object(frontend\\controllers\\QuarterController))\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(381): yii\\base\\View->render(\'update\', Array, Object(frontend\\controllers\\QuarterController))\n#9 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\QuarterController.php(94): yii\\base\\Controller->render(\'update\', Array)\n#10 [internal function]: frontend\\controllers\\QuarterController->actionUpdate(\'1\')\n#11 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#12 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#13 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'update\', Array)\n#14 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'quarter/update\', Array)\n#15 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#16 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#17 {main}'),
(128, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502202523.0421, '[frontend][/quarter/update/1]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(129, 1, 'yii\\base\\ErrorException:8', 1502202523.0468, '[frontend][/quarter/update/1]', 'yii\\base\\ErrorException: Undefined variable: years in C:\\htdocs\\maktapp.loc\\frontend\\views\\quarter\\_form.php:19\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\frontend\\views\\quarter\\_form.php(19): yii\\base\\ErrorHandler->handleError(8, \'Undefined varia...\', \'C:\\\\htdocs\\\\makta...\', 19, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, NULL)\n#4 C:\\htdocs\\maktapp.loc\\frontend\\views\\quarter\\update.php(20): yii\\base\\View->render(\'_form\', Array)\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, Object(frontend\\controllers\\QuarterController))\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(381): yii\\base\\View->render(\'update\', Array, Object(frontend\\controllers\\QuarterController))\n#9 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\QuarterController.php(96): yii\\base\\Controller->render(\'update\', Array)\n#10 [internal function]: frontend\\controllers\\QuarterController->actionUpdate(\'1\')\n#11 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#12 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#13 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'update\', Array)\n#14 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'quarter/update\', Array)\n#15 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#16 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#17 {main}'),
(130, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502202539.9068, '[frontend][/quarter/update/1]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(131, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502202555.5449, '[frontend][/quarter/1]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(132, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502202566.5495, '[frontend][/quarter/update/1]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(133, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502202617.4304, '[frontend][/quarter/update/1]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(134, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502202629.7863, '[frontend][/quarter/1]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(135, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502202768.3125, '[frontend][/quarter/update/1]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(136, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502202840.5852, '[frontend][/quarter/update/1]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(137, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502202851.231, '[frontend][/quarter/1]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(138, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502202891.8232, '[frontend][/quarter/update/1]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(139, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502202898.8258, '[frontend][/quarter/1]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(140, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502202901.4659, '[frontend][/quarter/index]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(141, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502202903.6285, '[frontend][/quarter/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(142, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502202918.5438, '[frontend][/quarter/2]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(143, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502202924.3145, '[frontend][/lesson/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(144, 1, 'yii\\base\\UnknownPropertyException', 1502202924.4149, '[frontend][/lesson/create]', 'yii\\base\\UnknownPropertyException: Getting unknown property: common\\models\\Quarter::name in C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Component.php:147\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\db\\BaseActiveRecord.php(285): yii\\base\\Component->__get(\'name\')\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\helpers\\BaseArrayHelper.php(209): yii\\db\\BaseActiveRecord->__get(\'name\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\helpers\\BaseArrayHelper.php(503): yii\\helpers\\BaseArrayHelper::getValue(Object(common\\models\\Quarter), \'name\')\n#3 C:\\htdocs\\maktapp.loc\\frontend\\views\\lesson\\_form.php(35): yii\\helpers\\BaseArrayHelper::map(Array, \'id\', \'name\')\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, NULL)\n#7 C:\\htdocs\\maktapp.loc\\frontend\\views\\lesson\\create.php(26): yii\\base\\View->render(\'_form\', Array)\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#9 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, Object(frontend\\controllers\\LessonController))\n#11 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(381): yii\\base\\View->render(\'create\', Array, Object(frontend\\controllers\\LessonController))\n#12 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\LessonController.php(112): yii\\base\\Controller->render(\'create\', Array)\n#13 [internal function]: frontend\\controllers\\LessonController->actionCreate()\n#14 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#15 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#16 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'create\', Array)\n#17 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'lesson/create\', Array)\n#18 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#19 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#20 {main}'),
(145, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502202945.9342, '[frontend][/lesson/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(146, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502202985.3916, '[frontend][/lesson/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(147, 1, 'yii\\base\\UnknownPropertyException', 1502202985.4415, '[frontend][/lesson/create]', 'yii\\base\\UnknownPropertyException: Getting unknown property: common\\models\\User::name in C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Component.php:147\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\db\\BaseActiveRecord.php(285): yii\\base\\Component->__get(\'name\')\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\helpers\\BaseArrayHelper.php(209): yii\\db\\BaseActiveRecord->__get(\'name\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\helpers\\BaseArrayHelper.php(503): yii\\helpers\\BaseArrayHelper::getValue(Object(common\\models\\User), \'name\')\n#3 C:\\htdocs\\maktapp.loc\\frontend\\views\\lesson\\_form.php(35): yii\\helpers\\BaseArrayHelper::map(Array, \'id\', \'name\')\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, NULL)\n#7 C:\\htdocs\\maktapp.loc\\frontend\\views\\lesson\\create.php(26): yii\\base\\View->render(\'_form\', Array)\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#9 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, Object(frontend\\controllers\\LessonController))\n#11 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(381): yii\\base\\View->render(\'create\', Array, Object(frontend\\controllers\\LessonController))\n#12 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\LessonController.php(112): yii\\base\\Controller->render(\'create\', Array)\n#13 [internal function]: frontend\\controllers\\LessonController->actionCreate()\n#14 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#15 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#16 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'create\', Array)\n#17 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'lesson/create\', Array)\n#18 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#19 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#20 {main}'),
(148, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502203123.4994, '[frontend][/lesson/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(149, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502203316.3103, '[frontend][/lesson/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(150, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502203746.3415, '[frontend][/lesson/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(151, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502203776.0897, '[frontend][/lesson/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(152, 1, 'yii\\i18n\\PhpMessageSource::loadFallbackMessages', 1502203784.6768, '[frontend][/lesson/create]', 'The message file for category \'app\' does not exist: C:\\htdocs\\maktapp.loc\\common/messages/ru-RU/app.php Fallback file does not exist as well: C:\\htdocs\\maktapp.loc\\common/messages/ru/app.php'),
(153, 1, 'yii\\base\\InvalidConfigException', 1502205751.0923, '[frontend][/fonts/sf-ui-text-regular-webfont.ttf]', 'yii\\base\\InvalidConfigException: yii\\web\\Request::cookieValidationKey must be configured with a secret key. in C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php:1292\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php(1274): yii\\web\\Request->loadCookies()\n#1 C:\\htdocs\\maktapp.loc\\common\\behaviors\\LocaleBehavior.php(39): yii\\web\\Request->getCookies()\n#2 [internal function]: common\\behaviors\\LocaleBehavior->beforeRequest(Object(yii\\base\\Event))\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Component.php(545): call_user_func(Array, Object(yii\\base\\Event))\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(377): yii\\base\\Component->trigger(\'beforeRequest\')\n#5 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#6 {main}'),
(154, 2, 'yii\\log\\Dispatcher::dispatch', 1502205751.3321, '[frontend][/fonts/sf-ui-text-regular-webfont.ttf]', 'Unable to send log via yii\\debug\\LogTarget: Exception (Invalid Configuration) \'yii\\base\\InvalidConfigException\' with message \'yii\\web\\Request::cookieValidationKey must be configured with a secret key.\' \n\nin C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php:1292\n\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php(1274): yii\\web\\Request->loadCookies()\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\User.php(512): yii\\web\\Request->getCookies()\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\User.php(676): yii\\web\\User->renewIdentityCookie()\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\User.php(188): yii\\web\\User->renewAuthStatus()\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Component.php(132): yii\\web\\User->getIdentity()\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\panels\\UserPanel.php(54): yii\\base\\Component->__get(\'identity\')\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(54): yii\\debug\\panels\\UserPanel->save()\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(118): yii\\debug\\LogTarget->export()\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Dispatcher.php(188): yii\\debug\\LogTarget->collect(Array, true)\n#9 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Logger.php(177): yii\\log\\Dispatcher->dispatch(Array, true)\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\ErrorHandler.php(113): yii\\log\\Logger->flush(true)\n#11 [internal function]: yii\\base\\ErrorHandler->handleException(Object(yii\\base\\InvalidConfigException))\n#12 {main}'),
(155, 1, 'yii\\web\\Session::open', 1502205751.3118, '[frontend][/fonts/sf-ui-text-regular-webfont.ttf]', 'session_start(): Cannot send session cache limiter - headers already sent (output started at C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Response.php:412)');
INSERT INTO `system_log` (`id`, `level`, `category`, `log_time`, `prefix`, `message`) VALUES
(156, 1, 'yii\\base\\InvalidConfigException', 1502206159.8871, '[frontend][/fonts/sf-ui-text-bold-webfont.ttf]', 'yii\\base\\InvalidConfigException: yii\\web\\Request::cookieValidationKey must be configured with a secret key. in C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php:1292\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php(1274): yii\\web\\Request->loadCookies()\n#1 C:\\htdocs\\maktapp.loc\\common\\behaviors\\LocaleBehavior.php(39): yii\\web\\Request->getCookies()\n#2 [internal function]: common\\behaviors\\LocaleBehavior->beforeRequest(Object(yii\\base\\Event))\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Component.php(545): call_user_func(Array, Object(yii\\base\\Event))\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(377): yii\\base\\Component->trigger(\'beforeRequest\')\n#5 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#6 {main}'),
(157, 2, 'yii\\log\\Dispatcher::dispatch', 1502206160.251, '[frontend][/fonts/sf-ui-text-bold-webfont.ttf]', 'Unable to send log via yii\\debug\\LogTarget: Exception (Invalid Configuration) \'yii\\base\\InvalidConfigException\' with message \'yii\\web\\Request::cookieValidationKey must be configured with a secret key.\' \n\nin C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php:1292\n\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Request.php(1274): yii\\web\\Request->loadCookies()\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\User.php(512): yii\\web\\Request->getCookies()\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\User.php(676): yii\\web\\User->renewIdentityCookie()\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\User.php(188): yii\\web\\User->renewAuthStatus()\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Component.php(132): yii\\web\\User->getIdentity()\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\panels\\UserPanel.php(54): yii\\base\\Component->__get(\'identity\')\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(54): yii\\debug\\panels\\UserPanel->save()\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(118): yii\\debug\\LogTarget->export()\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Dispatcher.php(188): yii\\debug\\LogTarget->collect(Array, true)\n#9 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Logger.php(177): yii\\log\\Dispatcher->dispatch(Array, true)\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\ErrorHandler.php(113): yii\\log\\Logger->flush(true)\n#11 [internal function]: yii\\base\\ErrorHandler->handleException(Object(yii\\base\\InvalidConfigException))\n#12 {main}'),
(158, 1, 'yii\\web\\Session::open', 1502206160.2062, '[frontend][/fonts/sf-ui-text-bold-webfont.ttf]', 'session_start(): Cannot send session cache limiter - headers already sent (output started at C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Response.php:412)'),
(159, 1, 'yii\\base\\ErrorException:8', 1502207161.1574, '[frontend][/lesson/1]', 'yii\\base\\ErrorException: Trying to get property of non-object in C:\\htdocs\\maktapp.loc\\frontend\\views\\lesson\\view.php:33\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\frontend\\views\\lesson\\view.php(33): yii\\base\\ErrorHandler->handleError(8, \'Trying to get p...\', \'C:\\\\htdocs\\\\makta...\', 33, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, Object(frontend\\controllers\\LessonController))\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(381): yii\\base\\View->render(\'view\', Array, Object(frontend\\controllers\\LessonController))\n#5 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\LessonController.php(65): yii\\base\\Controller->render(\'view\', Array)\n#6 [internal function]: frontend\\controllers\\LessonController->actionView(\'1\')\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#9 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'view\', Array)\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'lesson/view\', Array)\n#11 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#12 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#13 {main}'),
(160, 1, 'Error', 1502207193.2741, '[frontend][/lesson/1]', 'Error: Call to a member function getSubjectName() on null in C:\\htdocs\\maktapp.loc\\frontend\\views\\lesson\\view.php:41\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require()\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, Object(frontend\\controllers\\LessonController))\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(381): yii\\base\\View->render(\'view\', Array, Object(frontend\\controllers\\LessonController))\n#4 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\LessonController.php(65): yii\\base\\Controller->render(\'view\', Array)\n#5 [internal function]: frontend\\controllers\\LessonController->actionView(\'1\')\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'view\', Array)\n#9 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'lesson/view\', Array)\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#11 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#12 {main}'),
(161, 1, 'yii\\base\\ErrorException:8', 1502207219.4586, '[frontend][/lesson/1]', 'yii\\base\\ErrorException: Trying to get property of non-object in C:\\htdocs\\maktapp.loc\\frontend\\views\\lesson\\view.php:53\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\frontend\\views\\lesson\\view.php(53): yii\\base\\ErrorHandler->handleError(8, \'Trying to get p...\', \'C:\\\\htdocs\\\\makta...\', 53, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, Object(frontend\\controllers\\LessonController))\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(381): yii\\base\\View->render(\'view\', Array, Object(frontend\\controllers\\LessonController))\n#5 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\LessonController.php(65): yii\\base\\Controller->render(\'view\', Array)\n#6 [internal function]: frontend\\controllers\\LessonController->actionView(\'1\')\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#9 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'view\', Array)\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'lesson/view\', Array)\n#11 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#12 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#13 {main}'),
(162, 1, 'yii\\base\\ErrorException:8', 1502207440.2915, '[frontend][/lesson/update/1]', 'yii\\base\\ErrorException: Undefined variable: years in C:\\htdocs\\maktapp.loc\\frontend\\views\\lesson\\_form.php:17\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\frontend\\views\\lesson\\_form.php(17): yii\\base\\ErrorHandler->handleError(8, \'Undefined varia...\', \'C:\\\\htdocs\\\\makta...\', 17, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, NULL)\n#4 C:\\htdocs\\maktapp.loc\\frontend\\views\\lesson\\update.php(20): yii\\base\\View->render(\'_form\', Array)\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, Object(frontend\\controllers\\LessonController))\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(381): yii\\base\\View->render(\'update\', Array, Object(frontend\\controllers\\LessonController))\n#9 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\LessonController.php(134): yii\\base\\Controller->render(\'update\', Array)\n#10 [internal function]: frontend\\controllers\\LessonController->actionUpdate(\'1\')\n#11 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#12 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#13 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'update\', Array)\n#14 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'lesson/update\', Array)\n#15 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#16 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#17 {main}'),
(163, 1, 'yii\\base\\ErrorException:8', 1502207489.7548, '[frontend][/lesson/update/1]', 'yii\\base\\ErrorException: Undefined variable: years in C:\\htdocs\\maktapp.loc\\frontend\\views\\lesson\\_form.php:17\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\frontend\\views\\lesson\\_form.php(17): yii\\base\\ErrorHandler->handleError(8, \'Undefined varia...\', \'C:\\\\htdocs\\\\makta...\', 17, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, NULL)\n#4 C:\\htdocs\\maktapp.loc\\frontend\\views\\lesson\\update.php(20): yii\\base\\View->render(\'_form\', Array)\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#6 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, Object(frontend\\controllers\\LessonController))\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(381): yii\\base\\View->render(\'update\', Array, Object(frontend\\controllers\\LessonController))\n#9 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\LessonController.php(159): yii\\base\\Controller->render(\'update\', Array)\n#10 [internal function]: frontend\\controllers\\LessonController->actionUpdate(\'1\')\n#11 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#12 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#13 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'update\', Array)\n#14 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'lesson/update\', Array)\n#15 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#16 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#17 {main}'),
(164, 1, 'yii\\base\\ErrorException:4096', 1502207606.6108, '[frontend][/lesson/4]', 'yii\\base\\ErrorException: Object of class common\\models\\Subject could not be converted to string in C:\\htdocs\\maktapp.loc\\frontend\\views\\lesson\\view.php:41\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\frontend\\views\\lesson\\view.php(41): yii\\base\\ErrorHandler->handleError(4096, \'Object of class...\', \'C:\\\\htdocs\\\\makta...\', 41, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, Object(frontend\\controllers\\LessonController))\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(381): yii\\base\\View->render(\'view\', Array, Object(frontend\\controllers\\LessonController))\n#5 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\LessonController.php(65): yii\\base\\Controller->render(\'view\', Array)\n#6 [internal function]: frontend\\controllers\\LessonController->actionView(\'4\')\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#9 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'view\', Array)\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'lesson/view\', Array)\n#11 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#12 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#13 {main}'),
(165, 1, 'yii\\base\\ErrorException:8', 1502207662.815, '[frontend][/lesson/4]', 'yii\\base\\ErrorException: Trying to get property of non-object in C:\\htdocs\\maktapp.loc\\frontend\\views\\lesson\\view.php:53\nStack trace:\n#0 C:\\htdocs\\maktapp.loc\\frontend\\views\\lesson\\view.php(53): yii\\base\\ErrorHandler->handleError(8, \'Trying to get p...\', \'C:\\\\htdocs\\\\makta...\', 53, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(330): require(\'C:\\\\htdocs\\\\makta...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(250): yii\\base\\View->renderPhpFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\View.php(152): yii\\base\\View->renderFile(\'C:\\\\htdocs\\\\makta...\', Array, Object(frontend\\controllers\\LessonController))\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(381): yii\\base\\View->render(\'view\', Array, Object(frontend\\controllers\\LessonController))\n#5 C:\\htdocs\\maktapp.loc\\frontend\\controllers\\LessonController.php(65): yii\\base\\Controller->render(\'view\', Array)\n#6 [internal function]: frontend\\controllers\\LessonController->actionView(\'4\')\n#7 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\InlineAction.php(57): call_user_func_array(Array, Array)\n#8 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Controller.php(156): yii\\base\\InlineAction->runWithParams(Array)\n#9 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Module.php(523): yii\\base\\Controller->runAction(\'view\', Array)\n#10 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\web\\Application.php(102): yii\\base\\Module->runAction(\'lesson/view\', Array)\n#11 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\base\\Application.php(380): yii\\web\\Application->handleRequest(Object(yii\\web\\Request))\n#12 C:\\htdocs\\maktapp.loc\\frontend\\web\\index.php(22): yii\\base\\Application->run()\n#13 {main}'),
(166, 2, 'yii\\log\\Dispatcher::dispatch', 1502281824.3865, '[backend][/sign-in/login]', 'Unable to send log via yii\\debug\\LogTarget: PHP Notice \'yii\\base\\ErrorException\' with message \'unserialize(): Error at offset 22 of 17513 bytes\' \n\nin C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php:88\n\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleError(8, \'unserialize(): ...\', \'C:\\\\htdocs\\\\makta...\', 88, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(88): unserialize(\'a:60:{i:5982199...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(63): yii\\debug\\LogTarget->updateIndexFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(118): yii\\debug\\LogTarget->export()\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Dispatcher.php(188): yii\\debug\\LogTarget->collect(Array, true)\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Logger.php(177): yii\\log\\Dispatcher->dispatch(Array, true)\n#6 [internal function]: yii\\log\\Logger->flush(true)\n#7 {main}'),
(167, 2, 'yii\\log\\Dispatcher::dispatch', 1502281833.5382, '[backend][/sign-in/login]', 'Unable to send log via yii\\debug\\LogTarget: PHP Notice \'yii\\base\\ErrorException\' with message \'unserialize(): Error at offset 22 of 17513 bytes\' \n\nin C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php:88\n\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleError(8, \'unserialize(): ...\', \'C:\\\\htdocs\\\\makta...\', 88, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(88): unserialize(\'a:60:{i:5982199...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(63): yii\\debug\\LogTarget->updateIndexFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(118): yii\\debug\\LogTarget->export()\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Dispatcher.php(188): yii\\debug\\LogTarget->collect(Array, true)\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Logger.php(177): yii\\log\\Dispatcher->dispatch(Array, true)\n#6 [internal function]: yii\\log\\Logger->flush(true)\n#7 {main}'),
(168, 2, 'yii\\log\\Dispatcher::dispatch', 1502281836.6747, '[backend][/]', 'Unable to send log via yii\\debug\\LogTarget: PHP Notice \'yii\\base\\ErrorException\' with message \'unserialize(): Error at offset 22 of 17513 bytes\' \n\nin C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php:88\n\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleError(8, \'unserialize(): ...\', \'C:\\\\htdocs\\\\makta...\', 88, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(88): unserialize(\'a:60:{i:5982199...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(63): yii\\debug\\LogTarget->updateIndexFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(118): yii\\debug\\LogTarget->export()\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Dispatcher.php(188): yii\\debug\\LogTarget->collect(Array, true)\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Logger.php(177): yii\\log\\Dispatcher->dispatch(Array, true)\n#6 [internal function]: yii\\log\\Logger->flush(true)\n#7 {main}'),
(169, 2, 'yii\\log\\Dispatcher::dispatch', 1502281862.2432, '[backend][/user/index]', 'Unable to send log via yii\\debug\\LogTarget: PHP Notice \'yii\\base\\ErrorException\' with message \'unserialize(): Error at offset 22 of 17513 bytes\' \n\nin C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php:88\n\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleError(8, \'unserialize(): ...\', \'C:\\\\htdocs\\\\makta...\', 88, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(88): unserialize(\'a:60:{i:5982199...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(63): yii\\debug\\LogTarget->updateIndexFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(118): yii\\debug\\LogTarget->export()\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Dispatcher.php(188): yii\\debug\\LogTarget->collect(Array, true)\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Logger.php(177): yii\\log\\Dispatcher->dispatch(Array, true)\n#6 [internal function]: yii\\log\\Logger->flush(true)\n#7 {main}'),
(170, 2, 'yii\\log\\Dispatcher::dispatch', 1502281872.2295, '[backend][/user/update/7]', 'Unable to send log via yii\\debug\\LogTarget: PHP Notice \'yii\\base\\ErrorException\' with message \'unserialize(): Error at offset 22 of 17513 bytes\' \n\nin C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php:88\n\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleError(8, \'unserialize(): ...\', \'C:\\\\htdocs\\\\makta...\', 88, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(88): unserialize(\'a:60:{i:5982199...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(63): yii\\debug\\LogTarget->updateIndexFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(118): yii\\debug\\LogTarget->export()\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Dispatcher.php(188): yii\\debug\\LogTarget->collect(Array, true)\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Logger.php(177): yii\\log\\Dispatcher->dispatch(Array, true)\n#6 [internal function]: yii\\log\\Logger->flush(true)\n#7 {main}'),
(171, 2, 'yii\\log\\Dispatcher::dispatch', 1502281876.9607, '[backend][/user/update/7]', 'Unable to send log via yii\\debug\\LogTarget: PHP Notice \'yii\\base\\ErrorException\' with message \'unserialize(): Error at offset 22 of 17513 bytes\' \n\nin C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php:88\n\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleError(8, \'unserialize(): ...\', \'C:\\\\htdocs\\\\makta...\', 88, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(88): unserialize(\'a:60:{i:5982199...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(63): yii\\debug\\LogTarget->updateIndexFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(118): yii\\debug\\LogTarget->export()\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Dispatcher.php(188): yii\\debug\\LogTarget->collect(Array, true)\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Logger.php(177): yii\\log\\Dispatcher->dispatch(Array, true)\n#6 [internal function]: yii\\log\\Logger->flush(true)\n#7 {main}'),
(172, 2, 'yii\\log\\Dispatcher::dispatch', 1502281877.3377, '[backend][/user/index]', 'Unable to send log via yii\\debug\\LogTarget: PHP Notice \'yii\\base\\ErrorException\' with message \'unserialize(): Error at offset 22 of 17513 bytes\' \n\nin C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php:88\n\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleError(8, \'unserialize(): ...\', \'C:\\\\htdocs\\\\makta...\', 88, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(88): unserialize(\'a:60:{i:5982199...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(63): yii\\debug\\LogTarget->updateIndexFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(118): yii\\debug\\LogTarget->export()\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Dispatcher.php(188): yii\\debug\\LogTarget->collect(Array, true)\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Logger.php(177): yii\\log\\Dispatcher->dispatch(Array, true)\n#6 [internal function]: yii\\log\\Logger->flush(true)\n#7 {main}'),
(173, 2, 'yii\\log\\Dispatcher::dispatch', 1502281881.1928, '[backend][/user/update/6]', 'Unable to send log via yii\\debug\\LogTarget: PHP Notice \'yii\\base\\ErrorException\' with message \'unserialize(): Error at offset 22 of 17513 bytes\' \n\nin C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php:88\n\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleError(8, \'unserialize(): ...\', \'C:\\\\htdocs\\\\makta...\', 88, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(88): unserialize(\'a:60:{i:5982199...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(63): yii\\debug\\LogTarget->updateIndexFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(118): yii\\debug\\LogTarget->export()\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Dispatcher.php(188): yii\\debug\\LogTarget->collect(Array, true)\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Logger.php(177): yii\\log\\Dispatcher->dispatch(Array, true)\n#6 [internal function]: yii\\log\\Logger->flush(true)\n#7 {main}'),
(174, 2, 'yii\\log\\Dispatcher::dispatch', 1502281886.0846, '[backend][/user/update/6]', 'Unable to send log via yii\\debug\\LogTarget: PHP Notice \'yii\\base\\ErrorException\' with message \'unserialize(): Error at offset 22 of 17513 bytes\' \n\nin C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php:88\n\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleError(8, \'unserialize(): ...\', \'C:\\\\htdocs\\\\makta...\', 88, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(88): unserialize(\'a:60:{i:5982199...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(63): yii\\debug\\LogTarget->updateIndexFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(118): yii\\debug\\LogTarget->export()\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Dispatcher.php(188): yii\\debug\\LogTarget->collect(Array, true)\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Logger.php(177): yii\\log\\Dispatcher->dispatch(Array, true)\n#6 [internal function]: yii\\log\\Logger->flush(true)\n#7 {main}'),
(175, 2, 'yii\\log\\Dispatcher::dispatch', 1502281886.6807, '[backend][/user/index]', 'Unable to send log via yii\\debug\\LogTarget: PHP Notice \'yii\\base\\ErrorException\' with message \'unserialize(): Error at offset 22 of 17513 bytes\' \n\nin C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php:88\n\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleError(8, \'unserialize(): ...\', \'C:\\\\htdocs\\\\makta...\', 88, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(88): unserialize(\'a:60:{i:5982199...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(63): yii\\debug\\LogTarget->updateIndexFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(118): yii\\debug\\LogTarget->export()\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Dispatcher.php(188): yii\\debug\\LogTarget->collect(Array, true)\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Logger.php(177): yii\\log\\Dispatcher->dispatch(Array, true)\n#6 [internal function]: yii\\log\\Logger->flush(true)\n#7 {main}'),
(176, 2, 'yii\\log\\Dispatcher::dispatch', 1502284332.6705, '[backend][/gii]', 'Unable to send log via yii\\debug\\LogTarget: PHP Notice \'yii\\base\\ErrorException\' with message \'unserialize(): Error at offset 22 of 17513 bytes\' \n\nin C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php:88\n\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleError(8, \'unserialize(): ...\', \'C:\\\\htdocs\\\\makta...\', 88, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(88): unserialize(\'a:60:{i:5982199...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(63): yii\\debug\\LogTarget->updateIndexFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(118): yii\\debug\\LogTarget->export()\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Dispatcher.php(188): yii\\debug\\LogTarget->collect(Array, true)\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Logger.php(177): yii\\log\\Dispatcher->dispatch(Array, true)\n#6 [internal function]: yii\\log\\Logger->flush(true)\n#7 {main}'),
(177, 2, 'yii\\log\\Dispatcher::dispatch', 1502284336.1926, '[backend][/gii/model]', 'Unable to send log via yii\\debug\\LogTarget: PHP Notice \'yii\\base\\ErrorException\' with message \'unserialize(): Error at offset 22 of 17513 bytes\' \n\nin C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php:88\n\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleError(8, \'unserialize(): ...\', \'C:\\\\htdocs\\\\makta...\', 88, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(88): unserialize(\'a:60:{i:5982199...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(63): yii\\debug\\LogTarget->updateIndexFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(118): yii\\debug\\LogTarget->export()\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Dispatcher.php(188): yii\\debug\\LogTarget->collect(Array, true)\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Logger.php(177): yii\\log\\Dispatcher->dispatch(Array, true)\n#6 [internal function]: yii\\log\\Logger->flush(true)\n#7 {main}'),
(178, 2, 'yii\\log\\Dispatcher::dispatch', 1502284359.5623, '[backend][/gii/model]', 'Unable to send log via yii\\debug\\LogTarget: PHP Notice \'yii\\base\\ErrorException\' with message \'unserialize(): Error at offset 22 of 17513 bytes\' \n\nin C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php:88\n\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleError(8, \'unserialize(): ...\', \'C:\\\\htdocs\\\\makta...\', 88, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(88): unserialize(\'a:60:{i:5982199...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(63): yii\\debug\\LogTarget->updateIndexFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(118): yii\\debug\\LogTarget->export()\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Dispatcher.php(188): yii\\debug\\LogTarget->collect(Array, true)\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Logger.php(177): yii\\log\\Dispatcher->dispatch(Array, true)\n#6 [internal function]: yii\\log\\Logger->flush(true)\n#7 {main}'),
(179, 2, 'yii\\log\\Dispatcher::dispatch', 1502284368.4408, '[backend][/gii/model]', 'Unable to send log via yii\\debug\\LogTarget: PHP Notice \'yii\\base\\ErrorException\' with message \'unserialize(): Error at offset 22 of 17513 bytes\' \n\nin C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php:88\n\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleError(8, \'unserialize(): ...\', \'C:\\\\htdocs\\\\makta...\', 88, Array)\n#1 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(88): unserialize(\'a:60:{i:5982199...\')\n#2 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(63): yii\\debug\\LogTarget->updateIndexFile(\'C:\\\\htdocs\\\\makta...\', Array)\n#3 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2-debug\\LogTarget.php(118): yii\\debug\\LogTarget->export()\n#4 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Dispatcher.php(188): yii\\debug\\LogTarget->collect(Array, true)\n#5 C:\\htdocs\\maktapp.loc\\vendor\\yiisoft\\yii2\\log\\Logger.php(177): yii\\log\\Dispatcher->dispatch(Array, true)\n#6 [internal function]: yii\\log\\Logger->flush(true)\n#7 {main}');

-- --------------------------------------------------------

--
-- Структура таблицы `system_rbac_migration`
--

CREATE TABLE `system_rbac_migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `system_rbac_migration`
--

INSERT INTO `system_rbac_migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1501684576),
('m150625_214101_roles', 1501684589),
('m150625_215624_init_permissions', 1501684589),
('m151223_074604_edit_own_model', 1501684589);

-- --------------------------------------------------------

--
-- Структура таблицы `timeline_event`
--

CREATE TABLE `timeline_event` (
  `id` int(11) NOT NULL,
  `application` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `category` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `event` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `timeline_event`
--

INSERT INTO `timeline_event` (`id`, `application`, `category`, `event`, `data`, `created_at`) VALUES
(1, 'frontend', 'user', 'signup', '{\"public_identity\":\"webmaster\",\"user_id\":1,\"created_at\":1501684574}', 1501684574),
(2, 'frontend', 'user', 'signup', '{\"public_identity\":\"manager\",\"user_id\":2,\"created_at\":1501684574}', 1501684574),
(3, 'frontend', 'user', 'signup', '{\"public_identity\":\"user\",\"user_id\":3,\"created_at\":1501684574}', 1501684574),
(4, 'backend', 'user', 'signup', '{\"public_identity\":\"tamara.babaeva\",\"user_id\":4,\"created_at\":1501698671}', 1501698671),
(5, 'backend', 'user', 'signup', '{\"public_identity\":\"marina.borisovna\",\"user_id\":5,\"created_at\":1501698707}', 1501698707),
(6, 'backend', 'user', 'signup', '{\"public_identity\":\"alesha.qwe\",\"user_id\":6,\"created_at\":1501704124}', 1501704124);

-- --------------------------------------------------------

--
-- Структура таблицы `timing_types`
--

CREATE TABLE `timing_types` (
  `id` int(11) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `timing_types`
--

INSERT INTO `timing_types` (`id`, `start_time`, `end_time`) VALUES
(1, '08:30:00', '09:15:00'),
(2, '09:20:00', '10:05:00'),
(3, '10:15:00', '11:00:00'),
(4, '11:25:00', '12:10:00'),
(5, '12:30:00', '13:15:00'),
(6, '13:20:00', '14:05:00'),
(7, '14:15:00', '15:00:00'),
(8, '15:05:00', '15:50:00');

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `access_token` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `oauth_client` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `oauth_client_user_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '2',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `logged_at` int(11) DEFAULT NULL,
  `school_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `access_token`, `password_hash`, `oauth_client`, `oauth_client_user_id`, `email`, `status`, `created_at`, `updated_at`, `logged_at`, `school_id`, `parent_id`, `class_id`) VALUES
(1, 'webmaster', 'ZIcHaBUSVtaAHACYMNcvygWMtvwyU3yH', '1nPfIvu6PDpaBvvm6M9l-f9tGfd7ZiaQ2Z5N4tiP', '$2y$13$dFc2L8y4pHjIXxtoEK5ubOZfBwtYRd.PHgp.WXW1Yv.OFHZpsYXd2', NULL, NULL, 'webmaster@example.com', 2, 1501684575, 1501698327, 1502281833, 0, 0, 0),
(2, 'manager', 'El8K6Hnkx80gzvlEurEHougL3u8DCqqN', 'thGUMyeWcE95WIrU0AF4bVYb5D2sYDCMDY91MzRS', '$2y$13$1cLSp24hiBSq3XJlBssnAOJNsPWMG9i7Zi32AXqainF.1JeeFJexW', NULL, NULL, 'manager@example.com', 2, 1501684576, 1501684576, NULL, 0, 0, 0),
(3, 'user', 'noDUUxgAjlS8idMNDQrViyWF339HpgOJ', '1x8XtgbNUELTeLnM-Y1pr7icF5w03oun4xDPqbuF', '$2y$13$lB5Z8y1ToSwJgo93UWmtr.HZeKCF838I1adjBYxcBgsseeozzrePC', NULL, NULL, 'user@example.com', 2, 1501684576, 1501684576, NULL, 0, 0, 0),
(4, 'tamara.babaeva', 'fVKvbHrXt4AdaLkNsmFdVh46NLZbDm_p', '9Fyu_g8G4TrTJiLR92h1GSeFvQoE5yDmH-C2PFST', '$2y$13$BvQFMxIAb6CJZbN2izh6Suyz9dPiozUnZlpke8HFWjHI.vHWZ7UNe', NULL, NULL, 'tamara.babaeva@qwe.qw', 2, 1501698671, 1501698671, NULL, 1, 0, 0),
(5, 'marina.borisovna', 'iVchcMtjLcPsjln-2uoHb8KQFVuKfLkf', 'FKZ1_Sa5Mdq-oL9TntKUBNaM_uwPHF6PehYc6O6F', '$2y$13$2lAQstHpQ50uxEsNQjkpfez3KJW.iEM9B15DEfBoF0EXR6QfgtYAi', NULL, NULL, 'marina.borisovna@asd.as', 2, 1501698707, 1501698707, 1501793686, 1, 0, 0),
(6, 'alesha.qwe', '4YV4393jZK2EAYzQ7uNVsTfteG9Yw1G8', 'FPUilkm7UMXAIP0lTvw0msbg3Tq5aZhALbFauykt', '$2y$13$VWdxrgHKbFcycMOi5F6cOePu2u0wDBFfsA3stB6jl7am4.BmdDaOO', NULL, NULL, 'alesha.qwe@asd.as', 2, 1501704124, 1502281884, NULL, 1, 0, 2),
(7, 'vanya.pupkin', '217cgszEASc1R3YX4bssh3VxXf66fxk7', 'S6PsOP-U8DDE-g8o52ov2kdL4XAX3EtKFBKBTQQ1', '', NULL, NULL, 'vanya.pupkin@gmail.com', 2, 1502032752, 1502281876, NULL, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `user_profile`
--

CREATE TABLE `user_profile` (
  `user_id` int(11) NOT NULL,
  `firstname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `middlename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avatar_path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avatar_base_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locale` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `gender` smallint(1) DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `user_profile`
--

INSERT INTO `user_profile` (`user_id`, `firstname`, `middlename`, `lastname`, `avatar_path`, `avatar_base_url`, `locale`, `gender`, `phone`) VALUES
(1, 'John', NULL, 'Doe', NULL, NULL, 'en-US', NULL, NULL),
(2, NULL, NULL, NULL, NULL, NULL, 'en-US', NULL, NULL),
(3, NULL, NULL, NULL, NULL, NULL, 'en-US', NULL, NULL),
(4, NULL, NULL, NULL, NULL, NULL, 'en-US', NULL, NULL),
(5, NULL, NULL, NULL, NULL, NULL, 'en-US', NULL, NULL),
(6, NULL, NULL, NULL, NULL, NULL, 'en-US', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `user_token`
--

CREATE TABLE `user_token` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `token` varchar(40) NOT NULL,
  `expire_at` int(11) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `widget_carousel`
--

CREATE TABLE `widget_carousel` (
  `id` int(11) NOT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `widget_carousel`
--

INSERT INTO `widget_carousel` (`id`, `key`, `status`) VALUES
(1, 'index', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `widget_carousel_item`
--

CREATE TABLE `widget_carousel_item` (
  `id` int(11) NOT NULL,
  `carousel_id` int(11) NOT NULL,
  `base_url` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `caption` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `order` int(11) DEFAULT '0',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `widget_carousel_item`
--

INSERT INTO `widget_carousel_item` (`id`, `carousel_id`, `base_url`, `path`, `type`, `url`, `caption`, `status`, `order`, `created_at`, `updated_at`) VALUES
(1, 1, 'http://maktapp.hamsterland.uz', 'img/yii2-starter-kit.gif', 'image/gif', '/', NULL, 1, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `widget_menu`
--

CREATE TABLE `widget_menu` (
  `id` int(11) NOT NULL,
  `key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `items` text COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `widget_menu`
--

INSERT INTO `widget_menu` (`id`, `key`, `title`, `items`, `status`) VALUES
(1, 'frontend-index', 'Frontend index menu', '[\n    {\n        \"label\": \"Get started with Yii2\",\n        \"url\": \"http://www.yiiframework.com\",\n        \"options\": {\n            \"tag\": \"span\"\n        },\n        \"template\": \"<a href=\\\"{url}\\\" class=\\\"btn btn-lg btn-success\\\">{label}</a>\"\n    },\n    {\n        \"label\": \"Yii2 Starter Kit on GitHub\",\n        \"url\": \"https://github.com/trntv/yii2-starter-kit\",\n        \"options\": {\n            \"tag\": \"span\"\n        },\n        \"template\": \"<a href=\\\"{url}\\\" class=\\\"btn btn-lg btn-primary\\\">{label}</a>\"\n    },\n    {\n        \"label\": \"Find a bug?\",\n        \"url\": \"https://github.com/trntv/yii2-starter-kit/issues\",\n        \"options\": {\n            \"tag\": \"span\"\n        },\n        \"template\": \"<a href=\\\"{url}\\\" class=\\\"btn btn-lg btn-danger\\\">{label}</a>\"\n    }\n]', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `widget_text`
--

CREATE TABLE `widget_text` (
  `id` int(11) NOT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `widget_text`
--

INSERT INTO `widget_text` (`id`, `key`, `title`, `body`, `status`, `created_at`, `updated_at`) VALUES
(1, 'backend_welcome', 'Welcome to backend', '<p>Welcome to Yii2 Starter Kit Dashboard</p>', 1, 1501684576, 1501684576),
(2, 'ads-example', 'Google Ads Example Block', '<div class=\"lead\">\n                <script async src=\"//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js\"></script>\n                <ins class=\"adsbygoogle\"\n                     style=\"display:block\"\n                     data-ad-client=\"ca-pub-9505937224921657\"\n                     data-ad-slot=\"2264361777\"\n                     data-ad-format=\"auto\"></ins>\n                <script>\n                (adsbygoogle = window.adsbygoogle || []).push({});\n                </script>\n            </div>', 0, 1501684576, 1501684576);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `academic_year`
--
ALTER TABLE `academic_year`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_article_author` (`created_by`),
  ADD KEY `fk_article_updater` (`updated_by`),
  ADD KEY `fk_article_category` (`category_id`);

--
-- Индексы таблицы `article_attachment`
--
ALTER TABLE `article_attachment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_article_attachment_article` (`article_id`);

--
-- Индексы таблицы `article_category`
--
ALTER TABLE `article_category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_article_category_section` (`parent_id`);

--
-- Индексы таблицы `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `file_storage_item`
--
ALTER TABLE `file_storage_item`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `homework`
--
ALTER TABLE `homework`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `i18n_message`
--
ALTER TABLE `i18n_message`
  ADD PRIMARY KEY (`id`,`language`);

--
-- Индексы таблицы `i18n_source_message`
--
ALTER TABLE `i18n_source_message`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `key_storage_item`
--
ALTER TABLE `key_storage_item`
  ADD PRIMARY KEY (`key`),
  ADD UNIQUE KEY `idx_key_storage_item_key` (`key`);

--
-- Индексы таблицы `lesson`
--
ALTER TABLE `lesson`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `lesson_data`
--
ALTER TABLE `lesson_data`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `mark`
--
ALTER TABLE `mark`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `page`
--
ALTER TABLE `page`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `quarter`
--
ALTER TABLE `quarter`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `rbac_auth_assignment`
--
ALTER TABLE `rbac_auth_assignment`
  ADD PRIMARY KEY (`item_name`,`user_id`);

--
-- Индексы таблицы `rbac_auth_item`
--
ALTER TABLE `rbac_auth_item`
  ADD PRIMARY KEY (`name`),
  ADD KEY `rule_name` (`rule_name`),
  ADD KEY `idx-auth_item-type` (`type`);

--
-- Индексы таблицы `rbac_auth_item_child`
--
ALTER TABLE `rbac_auth_item_child`
  ADD PRIMARY KEY (`parent`,`child`),
  ADD KEY `child` (`child`);

--
-- Индексы таблицы `rbac_auth_rule`
--
ALTER TABLE `rbac_auth_rule`
  ADD PRIMARY KEY (`name`);

--
-- Индексы таблицы `school`
--
ALTER TABLE `school`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `system_db_migration`
--
ALTER TABLE `system_db_migration`
  ADD PRIMARY KEY (`version`);

--
-- Индексы таблицы `system_log`
--
ALTER TABLE `system_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_log_level` (`level`),
  ADD KEY `idx_log_category` (`category`);

--
-- Индексы таблицы `system_rbac_migration`
--
ALTER TABLE `system_rbac_migration`
  ADD PRIMARY KEY (`version`);

--
-- Индексы таблицы `timeline_event`
--
ALTER TABLE `timeline_event`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Индексы таблицы `timing_types`
--
ALTER TABLE `timing_types`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `user_profile`
--
ALTER TABLE `user_profile`
  ADD PRIMARY KEY (`user_id`);

--
-- Индексы таблицы `user_token`
--
ALTER TABLE `user_token`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `widget_carousel`
--
ALTER TABLE `widget_carousel`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `widget_carousel_item`
--
ALTER TABLE `widget_carousel_item`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_item_carousel` (`carousel_id`);

--
-- Индексы таблицы `widget_menu`
--
ALTER TABLE `widget_menu`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `widget_text`
--
ALTER TABLE `widget_text`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_widget_text_key` (`key`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `academic_year`
--
ALTER TABLE `academic_year`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `article`
--
ALTER TABLE `article`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `article_attachment`
--
ALTER TABLE `article_attachment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `article_category`
--
ALTER TABLE `article_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `class`
--
ALTER TABLE `class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT для таблицы `file_storage_item`
--
ALTER TABLE `file_storage_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `homework`
--
ALTER TABLE `homework`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `i18n_source_message`
--
ALTER TABLE `i18n_source_message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `lesson`
--
ALTER TABLE `lesson`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `lesson_data`
--
ALTER TABLE `lesson_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `mark`
--
ALTER TABLE `mark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `page`
--
ALTER TABLE `page`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `quarter`
--
ALTER TABLE `quarter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `school`
--
ALTER TABLE `school`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `subject`
--
ALTER TABLE `subject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `system_log`
--
ALTER TABLE `system_log`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=180;
--
-- AUTO_INCREMENT для таблицы `timeline_event`
--
ALTER TABLE `timeline_event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT для таблицы `timing_types`
--
ALTER TABLE `timing_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT для таблицы `user_profile`
--
ALTER TABLE `user_profile`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT для таблицы `user_token`
--
ALTER TABLE `user_token`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `widget_carousel`
--
ALTER TABLE `widget_carousel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `widget_carousel_item`
--
ALTER TABLE `widget_carousel_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `widget_menu`
--
ALTER TABLE `widget_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `widget_text`
--
ALTER TABLE `widget_text`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `article`
--
ALTER TABLE `article`
  ADD CONSTRAINT `fk_article_author` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_article_category` FOREIGN KEY (`category_id`) REFERENCES `article_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_article_updater` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `article_attachment`
--
ALTER TABLE `article_attachment`
  ADD CONSTRAINT `fk_article_attachment_article` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `article_category`
--
ALTER TABLE `article_category`
  ADD CONSTRAINT `fk_article_category_section` FOREIGN KEY (`parent_id`) REFERENCES `article_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `i18n_message`
--
ALTER TABLE `i18n_message`
  ADD CONSTRAINT `fk_i18n_message_source_message` FOREIGN KEY (`id`) REFERENCES `i18n_source_message` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `rbac_auth_assignment`
--
ALTER TABLE `rbac_auth_assignment`
  ADD CONSTRAINT `rbac_auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `rbac_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `rbac_auth_item`
--
ALTER TABLE `rbac_auth_item`
  ADD CONSTRAINT `rbac_auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `rbac_auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `rbac_auth_item_child`
--
ALTER TABLE `rbac_auth_item_child`
  ADD CONSTRAINT `rbac_auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `rbac_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `rbac_auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `rbac_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `user_profile`
--
ALTER TABLE `user_profile`
  ADD CONSTRAINT `fk_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `widget_carousel_item`
--
ALTER TABLE `widget_carousel_item`
  ADD CONSTRAINT `fk_item_carousel` FOREIGN KEY (`carousel_id`) REFERENCES `widget_carousel` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
